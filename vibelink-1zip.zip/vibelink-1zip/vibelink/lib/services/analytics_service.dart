import 'dart:convert';
import 'package:http/http.dart' as http;

/// Custom Analytics Service for VibeLink
/// Tracks user events and behaviors without Firebase dependency
class AnalyticsService {
  static const String _baseUrl = String.fromEnvironment(
    'ORACLE_API_BASE_URL',
    defaultValue: 'https://your-oracle-vps.com/api',
  );

  static const String _apiKey = String.fromEnvironment(
    'ORACLE_API_KEY',
    defaultValue: '',
  );

  static String? _authToken;
  static String? _userId;
  static String? _sessionId;

  /// Initialize analytics with user session
  static void initialize({String? authToken, String? userId}) {
    _authToken = authToken;
    _userId = userId;
    _sessionId = DateTime.now().millisecondsSinceEpoch.toString();
  }

  /// Track event view
  static Future<void> trackEventView({
    required String eventId,
    required String eventTitle,
    Map<String, dynamic>? metadata,
  }) async {
    await _trackEvent(
      eventType: 'event_view',
      eventName: 'Event Viewed',
      properties: {
        'event_id': eventId,
        'event_title': eventTitle,
        ...?metadata,
      },
    );
  }

  /// Track RSVP action
  static Future<void> trackRSVP({
    required String eventId,
    required String eventTitle,
    required bool isGoing,
  }) async {
    await _trackEvent(
      eventType: 'rsvp',
      eventName: isGoing ? 'Marked Going' : 'Unmarked Going',
      properties: {
        'event_id': eventId,
        'event_title': eventTitle,
        'is_going': isGoing,
      },
    );
  }

  /// Track ticket purchase
  static Future<void> trackTicketPurchase({
    required String eventId,
    required String eventTitle,
    required int quantity,
    required double amount,
  }) async {
    await _trackEvent(
      eventType: 'ticket_purchase',
      eventName: 'Ticket Purchased',
      properties: {
        'event_id': eventId,
        'event_title': eventTitle,
        'quantity': quantity,
        'amount': amount,
        'currency': 'ZAR',
      },
    );
  }

  /// Track travel booking
  static Future<void> trackTravelBooking({
    required String eventId,
    required String bookingType,
    required double amount,
  }) async {
    await _trackEvent(
      eventType: 'travel_booking',
      eventName: 'Travel Booked',
      properties: {
        'event_id': eventId,
        'booking_type': bookingType,
        'amount': amount,
      },
    );
  }

  /// Track ad impression
  static Future<void> trackAdImpression({
    required String eventId,
    required String adType,
  }) async {
    await _trackEvent(
      eventType: 'ad_impression',
      eventName: 'Ad Viewed',
      properties: {'event_id': eventId, 'ad_type': adType},
    );
  }

  /// Track ad click
  static Future<void> trackAdClick({
    required String eventId,
    required String adType,
  }) async {
    await _trackEvent(
      eventType: 'ad_click',
      eventName: 'Ad Clicked',
      properties: {'event_id': eventId, 'ad_type': adType},
    );
  }

  /// Track screen view
  static Future<void> trackScreenView(String screenName) async {
    await _trackEvent(
      eventType: 'screen_view',
      eventName: 'Screen Viewed',
      properties: {'screen_name': screenName},
    );
  }

  /// Track user engagement
  static Future<void> trackEngagement({
    required String action,
    Map<String, dynamic>? properties,
  }) async {
    await _trackEvent(
      eventType: 'engagement',
      eventName: action,
      properties: properties ?? {},
    );
  }

  /// Core tracking method
  static Future<void> _trackEvent({
    required String eventType,
    required String eventName,
    required Map<String, dynamic> properties,
  }) async {
    try {
      final headers = {
        'Content-Type': 'application/json',
        'X-API-Key': _apiKey,
        if (_authToken != null) 'Authorization': 'Bearer $_authToken',
      };

      final body = json.encode({
        'event_type': eventType,
        'event_name': eventName,
        'properties': properties,
        'user_id': _userId,
        'session_id': _sessionId,
        'timestamp': DateTime.now().toIso8601String(),
        'platform': 'flutter',
      });

      await http.post(
        Uri.parse('$_baseUrl/analytics/track'),
        headers: headers,
        body: body,
      );
    } catch (e) {
      // Silent fail - analytics should not break app functionality
      print('Analytics tracking failed: $e');
    }
  }
}
