import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

/// Verified badge widget for verified users and events
class VerifiedBadgeWidget extends StatelessWidget {
  final bool isVerified;
  final double size;

  const VerifiedBadgeWidget({
    super.key,
    required this.isVerified,
    this.size = 16,
  });

  @override
  Widget build(BuildContext context) {
    if (!isVerified) return const SizedBox.shrink();

    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.all(0.3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.secondary,
        shape: BoxShape.circle,
      ),
      child: Icon(
        Icons.check,
        color: theme.colorScheme.onSecondary,
        size: size,
      ),
    );
  }
}
