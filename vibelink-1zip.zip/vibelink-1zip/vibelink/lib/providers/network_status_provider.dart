import 'package:flutter/material.dart';
import '../services/enhanced_api_service.dart';

/// Network Status Provider
/// Manages network connectivity status across the app
class NetworkStatusProvider extends ChangeNotifier {
  bool _isConnected = true;
  bool _isCheckingConnection = false;

  bool get isConnected => _isConnected;
  bool get isCheckingConnection => _isCheckingConnection;

  NetworkStatusProvider() {
    _initializeConnectionListener();
    _checkInitialConnection();
  }

  /// Initialize connection status listener
  void _initializeConnectionListener() {
    EnhancedApiService.getConnectionStatusStream().listen((isConnected) {
      if (_isConnected != isConnected) {
        _isConnected = isConnected;
        notifyListeners();
      }
    });
  }

  /// Check initial connection status
  Future<void> _checkInitialConnection() async {
    _isCheckingConnection = true;
    notifyListeners();

    try {
      _isConnected = await EnhancedApiService.checkConnectivity();
    } catch (e) {
      _isConnected = false;
    } finally {
      _isCheckingConnection = false;
      notifyListeners();
    }
  }

  /// Manually refresh connection status
  Future<void> refreshConnectionStatus() async {
    _isCheckingConnection = true;
    notifyListeners();

    try {
      _isConnected = await EnhancedApiService.checkConnectivity();
    } catch (e) {
      _isConnected = false;
    } finally {
      _isCheckingConnection = false;
      notifyListeners();
    }
  }
}
