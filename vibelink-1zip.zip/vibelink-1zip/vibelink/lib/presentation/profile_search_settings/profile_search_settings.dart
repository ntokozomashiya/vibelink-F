import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../widgets/custom_bottom_bar.dart';
import './widgets/profile_tab_widget.dart';
import './widgets/search_tab_widget.dart';
import './widgets/settings_tab_widget.dart';

/// Profile, Search & Settings screen with tabbed interface
/// Consolidates user management through mobile-optimized navigation
class ProfileSearchSettings extends StatefulWidget {
  const ProfileSearchSettings({super.key});

  @override
  State<ProfileSearchSettings> createState() => _ProfileSearchSettingsState();
}

class _ProfileSearchSettingsState extends State<ProfileSearchSettings>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _currentBottomNavIndex = 4; // Profile tab is at index 4

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _handleBottomNavTap(int index) {
    HapticFeedback.lightImpact();

    // Navigate to different screens based on bottom nav selection
    switch (index) {
      case 0:
        Navigator.pushReplacementNamed(context, '/home-feed');
        break;
      case 1:
        Navigator.pushReplacementNamed(context, '/events-travel-hub');
        break;
      case 2:
        Navigator.pushReplacementNamed(context, '/create-vibe-event');
        break;
      case 3:
        Navigator.pushReplacementNamed(context, '/messaging-community');
        break;
      case 4:
        // Already on profile screen
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: theme.appBarTheme.backgroundColor,
        elevation: 0,
        title: Text(
          'Profile',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelColor: theme.colorScheme.primary,
          unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
          indicatorColor: theme.colorScheme.secondary,
          indicatorWeight: 3,
          labelStyle: theme.textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: theme.textTheme.labelLarge?.copyWith(
            fontWeight: FontWeight.w400,
          ),
          tabs: const [
            Tab(text: 'My Profile'),
            Tab(text: 'Search'),
            Tab(text: 'Settings'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          ProfileTabWidget(),
          SearchTabWidget(),
          SettingsTabWidget(),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: _currentBottomNavIndex,
        onTap: _handleBottomNavTap,
        badges: const {3: '5'}, // 5 unread messages
      ),
    );
  }
}
