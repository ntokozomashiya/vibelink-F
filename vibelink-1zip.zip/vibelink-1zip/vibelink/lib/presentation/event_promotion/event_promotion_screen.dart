import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/analytics_service.dart';
import '../../services/oracle_api_service.dart';
import '../../widgets/custom_icon_widget.dart';
import '../../widgets/payment_form_widget.dart';

class EventPromotionScreen extends StatefulWidget {
  const EventPromotionScreen({super.key});

  @override
  State<EventPromotionScreen> createState() => _EventPromotionScreenState();
}

class _EventPromotionScreenState extends State<EventPromotionScreen> {
  Map<String, dynamic>? _event;
  String _selectedAdType = 'featured';
  int _selectedDuration = 7;
  double _budget = 500.0;
  bool _isProcessing = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args != null && args is Map<String, dynamic>) {
      _event = args;
    }
  }

  Future<void> _createAd() async {
    if (_event == null) return;

    setState(() => _isProcessing = true);

    try {
      // Show payment form
      final paymentSuccess = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => PaymentFormWidget(
          amount: _budget,
          description: 'Event promotion for ${_event!['title']}',
          onPaymentSuccess: (paymentIntentId) async {
            Navigator.pop(context, true);
          },
        ),
      );

      if (paymentSuccess == true) {
        // Create ad campaign
        await OracleApiService.createEventAd(
          eventId: _event!['id'].toString(),
          adType: _selectedAdType,
          durationDays: _selectedDuration,
          budget: _budget,
        );

        // Track ad creation
        await AnalyticsService.trackEngagement(
          action: 'Event Ad Created',
          properties: {
            'event_id': _event!['id'].toString(),
            'ad_type': _selectedAdType,
            'duration': _selectedDuration,
            'budget': _budget,
          },
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Event promotion created successfully!'),
            ),
          );
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to create promotion: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_event == null) {
      return Scaffold(
        appBar: AppBar(backgroundColor: theme.colorScheme.surface),
        body: Center(
          child: Text('Event not found', style: theme.textTheme.bodyLarge),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            size: 6.w,
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Promote Event',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView(
        padding: EdgeInsets.all(4.w),
        children: [
          Text(
            'Boost your event visibility',
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Reach more people and increase ticket sales with targeted promotion',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 3.h),
          Text(
            'Ad Type',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          _buildAdTypeOption(
            theme,
            'featured',
            'Featured Event',
            'Appear at the top of event listings',
            Icons.star,
          ),
          _buildAdTypeOption(
            theme,
            'trending',
            'Trending Tonight',
            'Show in trending section',
            Icons.trending_up,
          ),
          _buildAdTypeOption(
            theme,
            'sponsored',
            'Sponsored Post',
            'Appear in user feeds',
            Icons.campaign,
          ),
          SizedBox(height: 3.h),
          Text(
            'Duration',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              _buildDurationChip(theme, 3, 'R 300'),
              SizedBox(width: 2.w),
              _buildDurationChip(theme, 7, 'R 500'),
              SizedBox(width: 2.w),
              _buildDurationChip(theme, 14, 'R 900'),
            ],
          ),
          SizedBox(height: 3.h),
          Text(
            'Budget',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(
                  'R ${_budget.toStringAsFixed(0)}',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    color: theme.colorScheme.secondary,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Slider(
                  value: _budget,
                  min: 100,
                  max: 5000,
                  divisions: 49,
                  activeColor: theme.colorScheme.secondary,
                  onChanged: (value) {
                    setState(() => _budget = value);
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 3.h),
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Estimated Reach',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildMetric(
                      theme,
                      'Impressions',
                      '${(_budget * 10).toInt()}',
                    ),
                    _buildMetric(theme, 'Clicks', '${(_budget * 0.5).toInt()}'),
                    _buildMetric(theme, 'Duration', '$_selectedDuration days'),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 4.h),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isProcessing ? null : _createAd,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 2.h),
              ),
              child: _isProcessing
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: theme.colorScheme.onSecondary,
                      ),
                    )
                  : Text('Create Promotion - R ${_budget.toStringAsFixed(0)}'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdTypeOption(
    ThemeData theme,
    String value,
    String title,
    String description,
    IconData icon,
  ) {
    final isSelected = _selectedAdType == value;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _selectedAdType = value;
          _budget = value == 'featured'
              ? 500
              : value == 'trending'
              ? 700
              : 1000;
        });
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 2.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: isSelected
              ? theme.colorScheme.secondaryContainer
              : theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? theme.colorScheme.secondary
                : Colors.transparent,
            width: 2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.colorScheme.secondary
                    : theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isSelected
                    ? theme.colorScheme.onSecondary
                    : theme.colorScheme.onSurfaceVariant,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    description,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              CustomIconWidget(
                iconName: 'check_circle',
                size: 24,
                color: theme.colorScheme.secondary,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildDurationChip(ThemeData theme, int days, String price) {
    final isSelected = _selectedDuration == days;

    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.lightImpact();
          setState(() {
            _selectedDuration = days;
            _budget = double.parse(price.replaceAll('R ', ''));
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 1.5.h),
          decoration: BoxDecoration(
            color: isSelected
                ? theme.colorScheme.secondary
                : theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Text(
                '$days days',
                style: theme.textTheme.titleSmall?.copyWith(
                  color: isSelected
                      ? theme.colorScheme.onSecondary
                      : theme.colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                price,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: isSelected
                      ? theme.colorScheme.onSecondary
                      : theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetric(ThemeData theme, String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}
