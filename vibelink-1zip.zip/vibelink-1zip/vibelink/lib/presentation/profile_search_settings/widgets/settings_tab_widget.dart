import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/oracle_api_service.dart';

/// Settings tab for account, security, and preferences management
class SettingsTabWidget extends StatefulWidget {
  const SettingsTabWidget({super.key});

  @override
  State<SettingsTabWidget> createState() => _SettingsTabWidgetState();
}

class _SettingsTabWidgetState extends State<SettingsTabWidget> {
  bool _biometricEnabled = true;
  bool _twoFactorEnabled = false;
  bool _pushNotifications = true;
  bool _emailNotifications = false;
  bool _profileVisibility = true;
  bool _safetyModeEnabled = false;
  bool _locationSharingEnabled = false;

  void _showSettingDetail(String title, Widget content) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildSettingDetailModal(title, content),
    );
  }

  Widget _buildSettingDetailModal(String title, Widget content) {
    final theme = Theme.of(context);

    return Container(
      height: 70.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Modal header
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'arrow_back',
                    size: 6.w,
                    color: theme.colorScheme.onSurface,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  title,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(width: 12.w), // Balance the back button
              ],
            ),
          ),
          // Modal content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: content,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final themeProvider = Provider.of<ThemeProvider>(context);

    return ListView(
      padding: EdgeInsets.symmetric(vertical: 2.h),
      children: [
        // Appearance section
        _buildSectionHeader('Appearance', theme),
        _buildSwitchTile(
          icon: 'dark_mode',
          title: 'Dark Mode',
          subtitle: 'Switch between light and dark theme',
          value: themeProvider.isDarkMode,
          onChanged: (value) {
            themeProvider.toggleTheme();
          },
          theme: theme,
        ),
        const Divider(),

        // Account section
        _buildSectionHeader('Account', theme),
        _buildSettingTile(
          icon: 'email',
          title: 'Email',
          subtitle: 'sarah.johnson@example.com',
          theme: theme,
          onTap: () =>
              _showSettingDetail('Email', _buildAccountEmailContent(theme)),
        ),
        _buildSettingTile(
          icon: 'phone',
          title: 'Phone Number',
          subtitle: '+27 82 555 1234',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Phone Number',
            _buildAccountPhoneContent(theme),
          ),
        ),
        _buildSettingTile(
          icon: 'lock',
          title: 'Password',
          subtitle: 'Change your password',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Password',
            _buildAccountPasswordContent(theme),
          ),
        ),
        _buildSettingTile(
          icon: 'delete',
          title: 'Delete Account',
          subtitle: 'Permanently delete your account',
          theme: theme,
          isDestructive: true,
          onTap: () {
            HapticFeedback.lightImpact();
            _showDeleteAccountDialog(theme);
          },
        ),
        SizedBox(height: 2.h),

        // Security section
        _buildSectionHeader('Security', theme),
        _buildSwitchTile(
          icon: 'fingerprint',
          title: 'Biometric Authentication',
          subtitle: 'Use fingerprint or face ID',
          value: _biometricEnabled,
          theme: theme,
          onChanged: (value) {
            HapticFeedback.lightImpact();
            setState(() => _biometricEnabled = value);
          },
        ),
        _buildSwitchTile(
          icon: 'security',
          title: 'Two-Factor Authentication',
          subtitle: 'Add extra security to your account',
          value: _twoFactorEnabled,
          theme: theme,
          onChanged: (value) {
            HapticFeedback.lightImpact();
            setState(() => _twoFactorEnabled = value);
          },
        ),
        _buildSettingTile(
          icon: 'devices',
          title: 'Active Sessions',
          subtitle: 'Manage your logged-in devices',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Active Sessions',
            _buildActiveSessionsContent(theme),
          ),
        ),
        SizedBox(height: 2.h),

        // Payments section
        _buildSectionHeader('Payments', theme),
        _buildSettingTile(
          icon: 'credit_card',
          title: 'Payment Methods',
          subtitle: '2 cards linked',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Payment Methods',
            _buildPaymentMethodsContent(theme),
          ),
        ),
        _buildSettingTile(
          icon: 'receipt',
          title: 'Transaction History',
          subtitle: 'View your payment history',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Transaction History',
            _buildTransactionHistoryContent(theme),
          ),
        ),
        SizedBox(height: 2.h),

        // Notifications section
        _buildSectionHeader('Notifications', theme),
        _buildSwitchTile(
          icon: 'notifications',
          title: 'Push Notifications',
          subtitle: 'Receive notifications on your device',
          value: _pushNotifications,
          theme: theme,
          onChanged: (value) {
            HapticFeedback.lightImpact();
            setState(() => _pushNotifications = value);
          },
        ),
        _buildSwitchTile(
          icon: 'mail',
          title: 'Email Notifications',
          subtitle: 'Receive updates via email',
          value: _emailNotifications,
          theme: theme,
          onChanged: (value) {
            HapticFeedback.lightImpact();
            setState(() => _emailNotifications = value);
          },
        ),
        _buildSettingTile(
          icon: 'tune',
          title: 'Notification Preferences',
          subtitle: 'Customize what you receive',
          theme: theme,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.pushNamed(context, AppRoutes.notificationPreferences);
          },
        ),
        SizedBox(height: 2.h),

        // Privacy section
        _buildSectionHeader('Privacy', theme),
        _buildSwitchTile(
          icon: 'visibility',
          title: 'Profile Visibility',
          subtitle: 'Make your profile public',
          value: _profileVisibility,
          theme: theme,
          onChanged: (value) {
            HapticFeedback.lightImpact();
            setState(() => _profileVisibility = value);
          },
        ),
        _buildSettingTile(
          icon: 'block',
          title: 'Blocked Users',
          subtitle: 'Manage blocked accounts',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Blocked Users',
            _buildBlockedUsersContent(theme),
          ),
        ),
        _buildSettingTile(
          icon: 'privacy_tip',
          title: 'Data & Privacy',
          subtitle: 'Control your data',
          theme: theme,
          onTap: () => _showSettingDetail(
            'Data & Privacy',
            _buildDataPrivacyContent(theme),
          ),
        ),
        SizedBox(height: 2.h),

        // About section
        _buildSectionHeader('About', theme),
        _buildSettingTile(
          icon: 'info',
          title: 'About VibeLink',
          subtitle: 'Version 1.0.0',
          theme: theme,
          onTap: () {
            HapticFeedback.lightImpact();
          },
        ),
        _buildSettingTile(
          icon: 'description',
          title: 'Terms of Service',
          subtitle: 'Read our terms',
          theme: theme,
          onTap: () {
            HapticFeedback.lightImpact();
          },
        ),
        _buildSettingTile(
          icon: 'policy',
          title: 'Privacy Policy',
          subtitle: 'Read our privacy policy',
          theme: theme,
          onTap: () {
            HapticFeedback.lightImpact();
          },
        ),
        SizedBox(height: 2.h),

        // Logout button
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: ElevatedButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              _showLogoutDialog(theme);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: theme.colorScheme.error,
              foregroundColor: theme.colorScheme.onError,
              padding: EdgeInsets.symmetric(vertical: 1.5.h),
            ),
            child: const Text('Logout'),
          ),
        ),
        SizedBox(height: 4.h),
      ],
    );
  }

  bool _isAdmin() {
    return OracleApiService.currentUser?['is_admin'] == true;
  }

  void _showTrustedContactsModal() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildTrustedContactsModal(),
    );
  }

  Widget _buildTrustedContactsModal() {
    final theme = Theme.of(context);

    return Container(
      height: 70.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'close',
                    size: 6.w,
                    color: theme.colorScheme.onSurface,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  'Trusted Contacts',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextButton(
                  onPressed: () => _addTrustedContact(),
                  child: const Text('Add'),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: OracleApiService.getTrustedContacts(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(
                      color: theme.colorScheme.secondary,
                    ),
                  );
                }

                final contacts = snapshot.data ?? [];

                if (contacts.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.contacts_outlined,
                          size: 20.w,
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'No trusted contacts yet',
                          style: theme.textTheme.titleMedium,
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: EdgeInsets.all(4.w),
                  itemCount: contacts.length,
                  itemBuilder: (context, index) {
                    final contact = contacts[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: theme.colorScheme.secondary,
                        child: Text(
                          contact['name'][0].toUpperCase(),
                          style: TextStyle(
                            color: theme.colorScheme.onSecondary,
                          ),
                        ),
                      ),
                      title: Text(contact['name']),
                      subtitle: Text(contact['phone']),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () {},
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _addTrustedContact() {
    final nameController = TextEditingController();
    final phoneController = TextEditingController();
    final emailController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Trusted Contact'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            SizedBox(height: 1.h),
            TextField(
              controller: phoneController,
              decoration: const InputDecoration(labelText: 'Phone'),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 1.h),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.isNotEmpty &&
                  phoneController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.addTrustedContact(
                    name: nameController.text,
                    phone: phoneController.text,
                    email: emailController.text,
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Contact added successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to add: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void _showReportFraudModal() {
    final descriptionController = TextEditingController();
    String reportType = 'event';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Report Fraud'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              initialValue: reportType,
              decoration: const InputDecoration(labelText: 'Report Type'),
              items: const [
                DropdownMenuItem(value: 'event', child: Text('Fake Event')),
                DropdownMenuItem(value: 'user', child: Text('Suspicious User')),
                DropdownMenuItem(
                  value: 'payment',
                  child: Text('Payment Issue'),
                ),
                DropdownMenuItem(value: 'other', child: Text('Other')),
              ],
              onChanged: (value) {
                reportType = value!;
              },
            ),
            SizedBox(height: 2.h),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description',
                hintText: 'Describe the issue...',
              ),
              maxLines: 4,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (descriptionController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.reportFraud(
                    reportType: reportType,
                    targetId: 1,
                    description: descriptionController.text,
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Report submitted successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to report: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }

  void _showAdminDashboard() {
    Navigator.pushNamed(context, AppRoutes.adminDashboard);
  }

  Widget _buildSectionHeader(String title, ThemeData theme) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Text(
        title,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }

  Widget _buildSettingTile({
    required String icon,
    required String title,
    required String subtitle,
    required ThemeData theme,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return ListTile(
      leading: Container(
        width: 10.w,
        height: 10.w,
        decoration: BoxDecoration(
          color: isDestructive
              ? theme.colorScheme.error.withValues(alpha: 0.1)
              : theme.colorScheme.secondary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: CustomIconWidget(
            iconName: icon,
            size: 5.w,
            color: isDestructive
                ? theme.colorScheme.error
                : theme.colorScheme.secondary,
          ),
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600,
          color: isDestructive ? theme.colorScheme.error : null,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: theme.textTheme.bodySmall?.copyWith(
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
      trailing: CustomIconWidget(
        iconName: 'chevron_right',
        size: 5.w,
        color: theme.colorScheme.onSurfaceVariant,
      ),
      onTap: onTap,
    );
  }

  Widget _buildSwitchTile({
    required String icon,
    required String title,
    required String subtitle,
    required bool value,
    required ThemeData theme,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      secondary: Container(
        width: 10.w,
        height: 10.w,
        decoration: BoxDecoration(
          color: theme.colorScheme.secondary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: CustomIconWidget(
            iconName: icon,
            size: 5.w,
            color: theme.colorScheme.secondary,
          ),
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: theme.textTheme.bodySmall?.copyWith(
          color: theme.colorScheme.onSurfaceVariant,
        ),
      ),
      value: value,
      onChanged: onChanged,
    );
  }

  // Content builders for modal sheets
  Widget _buildAccountEmailContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current Email',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          initialValue: 'sarah.johnson@example.com',
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Enter email address'),
        ),
        SizedBox(height: 2.h),
        Text(
          'New Email',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(
            hintText: 'Enter new email address',
          ),
        ),
        SizedBox(height: 3.h),
        ElevatedButton(
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Email updated successfully')),
            );
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 6.h),
          ),
          child: const Text('Update Email'),
        ),
      ],
    );
  }

  Widget _buildAccountPhoneContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current Phone Number',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          initialValue: '+27 82 555 1234',
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Enter phone number'),
        ),
        SizedBox(height: 2.h),
        Text(
          'New Phone Number',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Enter new phone number'),
        ),
        SizedBox(height: 3.h),
        ElevatedButton(
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Phone number updated successfully'),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 6.h),
          ),
          child: const Text('Update Phone Number'),
        ),
      ],
    );
  }

  Widget _buildAccountPasswordContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current Password',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          obscureText: true,
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Enter current password'),
        ),
        SizedBox(height: 2.h),
        Text(
          'New Password',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          obscureText: true,
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Enter new password'),
        ),
        SizedBox(height: 2.h),
        Text(
          'Confirm New Password',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          obscureText: true,
          style: theme.textTheme.bodyLarge,
          decoration: const InputDecoration(hintText: 'Confirm new password'),
        ),
        SizedBox(height: 3.h),
        ElevatedButton(
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Password updated successfully')),
            );
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 6.h),
          ),
          child: const Text('Update Password'),
        ),
      ],
    );
  }

  Widget _buildActiveSessionsContent(ThemeData theme) {
    final sessions = [
      {
        "device": "iPhone 13 Pro",
        "location": "Cape Town, South Africa",
        "lastActive": "Active now",
        "isCurrent": true,
      },
      {
        "device": "MacBook Pro",
        "location": "Cape Town, South Africa",
        "lastActive": "2 hours ago",
        "isCurrent": false,
      },
    ];

    return Column(
      children: sessions.map((session) {
        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: theme.colorScheme.outline.withValues(alpha: 0.2),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'devices',
                        size: 5.w,
                        color: theme.colorScheme.secondary,
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        session["device"] as String,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  if (session["isCurrent"] == true)
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 2.w,
                        vertical: 0.5.h,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.secondary.withValues(
                          alpha: 0.1,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'Current',
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: theme.colorScheme.secondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
              SizedBox(height: 1.h),
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'location_on',
                    size: 4.w,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    session["location"] as String,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 0.5.h),
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'access_time',
                    size: 4.w,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    session["lastActive"] as String,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              if (session["isCurrent"] == false) ...[
                SizedBox(height: 1.h),
                TextButton(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                  },
                  child: const Text('End Session'),
                ),
              ],
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildPaymentMethodsContent(ThemeData theme) {
    final paymentMethods = [
      {"type": "Visa", "last4": "4242", "expiry": "12/26", "isDefault": true},
      {
        "type": "Mastercard",
        "last4": "5555",
        "expiry": "08/25",
        "isDefault": false,
      },
    ];

    return Column(
      children: [
        ...paymentMethods.map((method) {
          return Container(
            margin: EdgeInsets.only(bottom: 2.h),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 12.w,
                  height: 12.w,
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: 'credit_card',
                      size: 6.w,
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            '${method["type"]} •••• ${method["last4"]}',
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          if (method["isDefault"] == true) ...[
                            SizedBox(width: 2.w),
                            Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 2.w,
                                vertical: 0.5.h,
                              ),
                              decoration: BoxDecoration(
                                color: theme.colorScheme.secondary.withValues(
                                  alpha: 0.1,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Default',
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: theme.colorScheme.secondary,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        'Expires ${method["expiry"]}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'more_vert',
                    size: 5.w,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                  },
                ),
              ],
            ),
          );
        }),
        SizedBox(height: 2.h),
        OutlinedButton.icon(
          onPressed: () {
            HapticFeedback.lightImpact();
          },
          icon: CustomIconWidget(
            iconName: 'add',
            size: 5.w,
            color: theme.colorScheme.secondary,
          ),
          label: const Text('Add Payment Method'),
          style: OutlinedButton.styleFrom(
            minimumSize: Size(double.infinity, 6.h),
          ),
        ),
      ],
    );
  }

  Widget _buildTransactionHistoryContent(ThemeData theme) {
    final transactions = [
      {
        "title": "Summer Music Festival",
        "date": "05 Jan 2026",
        "amount": "R 250.00",
        "status": "Completed",
      },
      {
        "title": "Food & Wine Experience",
        "date": "28 Dec 2025",
        "amount": "R 450.00",
        "status": "Completed",
      },
      {
        "title": "Electro Nights",
        "date": "15 Dec 2025",
        "amount": "R 180.00",
        "status": "Completed",
      },
    ];

    return Column(
      children: transactions.map((transaction) {
        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: theme.colorScheme.outline.withValues(alpha: 0.2),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 12.w,
                height: 12.w,
                decoration: BoxDecoration(
                  color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'receipt',
                    size: 6.w,
                    color: theme.colorScheme.secondary,
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      transaction["title"] as String,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      transaction["date"] as String,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    transaction["amount"] as String,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    transaction["status"] as String,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildNotificationPreferencesContent(ThemeData theme) {
    return Column(
      children: [
        _buildPreferenceSwitch(
          'Event Reminders',
          'Get notified about upcoming events',
          true,
          theme,
        ),
        _buildPreferenceSwitch(
          'New Messages',
          'Notifications for new messages',
          true,
          theme,
        ),
        _buildPreferenceSwitch(
          'Event Updates',
          'Updates about events you\'re attending',
          true,
          theme,
        ),
        _buildPreferenceSwitch(
          'Social Activity',
          'Likes, comments, and follows',
          false,
          theme,
        ),
        _buildPreferenceSwitch(
          'Promotional',
          'Special offers and promotions',
          false,
          theme,
        ),
      ],
    );
  }

  Widget _buildPreferenceSwitch(
    String title,
    String subtitle,
    bool value,
    ThemeData theme,
  ) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      child: SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: Text(
          title,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        value: value,
        onChanged: (newValue) {
          HapticFeedback.lightImpact();
        },
      ),
    );
  }

  Widget _buildBlockedUsersContent(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'block',
            size: 15.w,
            color: theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.5),
          ),
          SizedBox(height: 2.h),
          Text(
            'No Blocked Users',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'You haven\'t blocked anyone yet',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildDataPrivacyContent(ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Your data is important to us. We collect and use your information to provide you with the best experience on VibeLink.',
          style: theme.textTheme.bodyMedium,
        ),
        SizedBox(height: 2.h),
        _buildDataOption(
          'Download Your Data',
          'Get a copy of your data',
          'download',
          theme,
        ),
        _buildDataOption(
          'Data Usage',
          'See how we use your data',
          'analytics',
          theme,
        ),
        _buildDataOption(
          'Third-Party Sharing',
          'Manage data sharing preferences',
          'share',
          theme,
        ),
      ],
    );
  }

  Widget _buildDataOption(
    String title,
    String subtitle,
    String icon,
    ThemeData theme,
  ) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Container(
          width: 12.w,
          height: 12.w,
          decoration: BoxDecoration(
            color: theme.colorScheme.secondary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Center(
            child: CustomIconWidget(
              iconName: icon,
              size: 6.w,
              color: theme.colorScheme.secondary,
            ),
          ),
        ),
        title: Text(
          title,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        trailing: CustomIconWidget(
          iconName: 'chevron_right',
          size: 5.w,
          color: theme.colorScheme.onSurfaceVariant,
        ),
        onTap: () {
          HapticFeedback.lightImpact();
        },
      ),
    );
  }

  void _showLogoutDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              Navigator.pop(context);
              Navigator.pushReplacementNamed(
                context,
                '/authentication-onboarding',
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: theme.colorScheme.error,
              foregroundColor: theme.colorScheme.onError,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _showDeleteAccountDialog(ThemeData theme) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text(
          'This action cannot be undone. All your data will be permanently deleted.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Account deletion initiated'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: theme.colorScheme.error,
              foregroundColor: theme.colorScheme.onError,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
