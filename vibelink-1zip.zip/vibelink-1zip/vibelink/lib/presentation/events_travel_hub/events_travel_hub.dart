import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/oracle_api_service.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/event_card_widget.dart';
import './widgets/filter_chip_widget.dart';
import './widgets/filter_modal_widget.dart';
import './widgets/flight_search_widget.dart';
import './widgets/stay_card_widget.dart';
import './widgets/transport_card_widget.dart';

/// Events & Travel Hub Screen
///
/// Consolidates event discovery and travel booking through tabbed interface
/// optimized for mobile browsing with Events, Transport, Stays, and Flights tabs.
class EventsTravelHub extends StatefulWidget {
  const EventsTravelHub({super.key});

  @override
  State<EventsTravelHub> createState() => _EventsTravelHubState();
}

class _EventsTravelHubState extends State<EventsTravelHub>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _currentBottomNavIndex = 1;
  final Map<String, String> _activeFilters = {};
  bool _isFilterModalOpen = false;
  bool _isLoadingEvents = false;
  List<Map<String, dynamic>> _events = [];
  bool _showHeatMap = false;
  List<Map<String, dynamic>> _heatMapData = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _loadEvents();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadEvents() async {
    setState(() => _isLoadingEvents = true);

    try {
      final events = await OracleApiService.fetchEvents(
        category: _activeFilters['vibeType'],
        location: _activeFilters['city'],
        page: 1,
        limit: 20,
      );

      setState(() {
        _events = events;
        _isLoadingEvents = false;
      });
    } catch (e) {
      setState(() => _isLoadingEvents = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load events: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _loadHeatMapData() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      final heatMapData = await OracleApiService.getHeatMapData(
        latitude: position.latitude,
        longitude: position.longitude,
        radius: 50.0,
      );

      setState(() {
        _heatMapData = heatMapData;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load heat map: ${e.toString()}')),
        );
      }
    }
  }

  void _showFilterModal() {
    setState(() => _isFilterModalOpen = true);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterModalWidget(
        activeFilters: _activeFilters,
        onApplyFilters: (filters) {
          setState(() {
            _activeFilters.clear();
            _activeFilters.addAll(filters);
            _isFilterModalOpen = false;
          });
          _loadEvents();
        },
      ),
    ).then((_) => setState(() => _isFilterModalOpen = false));
  }

  void _removeFilter(String key) {
    setState(() => _activeFilters.remove(key));
  }

  List<Map<String, dynamic>> get _filteredEvents {
    if (_activeFilters.isEmpty) return _events;

    return _events.where((event) {
      bool matches = true;

      if (_activeFilters.containsKey('city')) {
        matches = matches && event['city'] == _activeFilters['city'];
      }

      if (_activeFilters.containsKey('vibeType')) {
        matches = matches && event['vibeType'] == _activeFilters['vibeType'];
      }

      if (_activeFilters.containsKey('priceRange')) {
        final price = double.parse(
          (event['price'] as String).replaceAll('R ', '').replaceAll(',', ''),
        );
        final range = _activeFilters['priceRange'];
        if (range == 'Under R 300') {
          matches = matches && price < 300;
        } else if (range == 'R 300 - R 600') {
          matches = matches && price >= 300 && price <= 600;
        } else if (range == 'Over R 600') {
          matches = matches && price > 600;
        }
      }

      return matches;
    }).toList();
  }

  void _handleFilterChange(Map<String, String> filters) {
    setState(() {
      _activeFilters.clear();
      _activeFilters.addAll(filters);
    });
    _loadEvents();
  }

  void _handleBottomNavTap(int index) {
    HapticFeedback.lightImpact();
    setState(() => _currentBottomNavIndex = index);

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home-feed');
        break;
      case 1:
        // Already on Events & Travel Hub
        break;
      case 2:
        Navigator.pushNamed(context, '/create-vibe-event');
        break;
      case 3:
        Navigator.pushNamed(context, '/messaging-community');
        break;
      case 4:
        Navigator.pushNamed(context, '/profile-search-settings');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight + 48),
        child: Column(
          children: [
            AppBar(
              backgroundColor: theme.colorScheme.surface,
              elevation: 0,
              title: Text(
                'Events & Travel',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              actions: [
                IconButton(
                  icon: Icon(
                    _showHeatMap ? Icons.list : Icons.map,
                    color: theme.colorScheme.onSurface,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    setState(() => _showHeatMap = !_showHeatMap);
                    if (_showHeatMap) {
                      _loadHeatMapData();
                    }
                  },
                ),
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'notifications_outlined',
                    color: theme.colorScheme.onSurface,
                    size: 24,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                  },
                ),
                IconButton(
                  icon: CustomIconWidget(
                    iconName: _isFilterModalOpen
                        ? 'filter_alt'
                        : 'filter_alt_outlined',
                    color: _activeFilters.isNotEmpty
                        ? theme.colorScheme.secondary
                        : theme.colorScheme.onSurface,
                    size: 24,
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    _showFilterModal();
                  },
                ),
              ],
            ),
            Container(
              color: theme.colorScheme.surface,
              child: TabBar(
                controller: _tabController,
                labelColor: theme.colorScheme.primary,
                unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                indicatorColor: theme.colorScheme.secondary,
                indicatorWeight: 3,
                isScrollable: true,
                labelStyle: theme.textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: theme.textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w400,
                ),
                tabs: const [
                  Tab(text: 'Events'),
                  Tab(text: 'Group Travel'),
                  Tab(text: 'Transport'),
                  Tab(text: 'Stays'),
                  Tab(text: 'Flights'),
                ],
              ),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _showHeatMap ? _buildHeatMapView(theme) : _buildEventsTab(theme),
          _buildGroupTravelTab(theme),
          _buildTransportTab(theme),
          _buildStaysTab(theme),
          _buildFlightsTab(theme),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: _currentBottomNavIndex,
        onTap: _handleBottomNavTap,
        badges: const {3: '5'},
      ),
    );
  }

  Widget _buildHeatMapView(ThemeData theme) {
    return FutureBuilder<Position>(
      future: Geolocator.getCurrentPosition(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(
              color: theme.colorScheme.secondary,
            ),
          );
        }

        if (!snapshot.hasData) {
          return Center(
            child: Text(
              'Unable to get location',
              style: theme.textTheme.bodyLarge,
            ),
          );
        }

        final position = snapshot.data!;

        return Stack(
          children: [
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(position.latitude, position.longitude),
                zoom: 12,
              ),
              markers: _heatMapData
                  .map(
                    (hotspot) => Marker(
                      markerId: MarkerId(hotspot['id'].toString()),
                      position: LatLng(
                        hotspot['latitude'],
                        hotspot['longitude'],
                      ),
                      infoWindow: InfoWindow(
                        title: hotspot['title'],
                        snippet:
                            '${hotspot['attendees']} people | ${hotspot['events']} events',
                      ),
                      icon: BitmapDescriptor.defaultMarkerWithHue(
                        _getHeatIntensityColor(hotspot['intensity']),
                      ),
                    ),
                  )
                  .toSet(),
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
            ),
            Positioned(
              top: 2.h,
              left: 4.w,
              right: 4.w,
              child: Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: theme.colorScheme.shadow,
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.local_fire_department,
                      color: theme.colorScheme.secondary,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        'Live Vibe Heat Map',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      '${_heatMapData.length} hotspots',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  double _getHeatIntensityColor(int intensity) {
    if (intensity > 80) return BitmapDescriptor.hueRed;
    if (intensity > 50) return BitmapDescriptor.hueOrange;
    if (intensity > 20) return BitmapDescriptor.hueYellow;
    return BitmapDescriptor.hueGreen;
  }

  Widget _buildGroupTravelTab(ThemeData theme) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: OracleApiService.getGroupTrips(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(
              color: theme.colorScheme.secondary,
            ),
          );
        }

        final trips = snapshot.data ?? [];

        return Column(
          children: [
            Padding(
              padding: EdgeInsets.all(4.w),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _createGroupTrip(),
                  icon: const Icon(Icons.add),
                  label: const Text('Create Group Trip'),
                ),
              ),
            ),
            Expanded(
              child: trips.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.group_outlined,
                            size: 20.w,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            'No group trips yet',
                            style: theme.textTheme.titleMedium,
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            'Create a trip and invite friends',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      itemCount: trips.length,
                      itemBuilder: (context, index) {
                        return _buildGroupTripCard(trips[index], theme);
                      },
                    ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildGroupTripCard(Map<String, dynamic> trip, ThemeData theme) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  trip['title'] ?? 'Group Trip',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '${trip['members_count']} members',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: theme.colorScheme.secondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Icon(
                Icons.location_on,
                size: 4.w,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              SizedBox(width: 2.w),
              Text(
                trip['destination'] ?? 'Destination',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          SizedBox(height: 0.5.h),
          Row(
            children: [
              Icon(
                Icons.calendar_today,
                size: 4.w,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              SizedBox(width: 2.w),
              Text(
                '${trip['start_date']} - ${trip['end_date']}',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.attach_money, size: 16),
                  label: const Text('Split Costs'),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.chat, size: 16),
                  label: const Text('Group Chat'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _createGroupTrip() {
    final titleController = TextEditingController();
    final destinationController = TextEditingController();
    final emailsController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Group Trip'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Trip Title'),
              ),
              SizedBox(height: 2.h),
              TextField(
                controller: destinationController,
                decoration: const InputDecoration(labelText: 'Destination'),
              ),
              SizedBox(height: 2.h),
              TextField(
                controller: emailsController,
                decoration: const InputDecoration(
                  labelText: 'Member Emails',
                  hintText: 'email1@example.com, email2@example.com',
                ),
                maxLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty &&
                  destinationController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.createGroupTrip(
                    title: titleController.text,
                    destination: destinationController.text,
                    startDate: DateTime.now(),
                    endDate: DateTime.now().add(const Duration(days: 7)),
                    memberEmails: emailsController.text
                        .split(',')
                        .map((e) => e.trim())
                        .toList(),
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Group trip created!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                    setState(() {});
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to create: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  Widget _buildEventsTab(ThemeData theme) {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: CustomScrollView(
        slivers: [
          if (_activeFilters.isNotEmpty)
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _activeFilters.entries.map((entry) {
                    return FilterChipWidget(
                      label: entry.value,
                      onRemove: () => _removeFilter(entry.key),
                    );
                  }).toList(),
                ),
              ),
            ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.75,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              delegate: SliverChildBuilderDelegate((context, index) {
                final event = _filteredEvents[index];
                return EventCardWidget(
                  event: event,
                  onTap: () {
                    HapticFeedback.lightImpact();
                    // Navigate to event detail view
                  },
                );
              }, childCount: _filteredEvents.length),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransportTab(ThemeData theme) {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Ride Services',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          TransportCardWidget(
            service: 'Uber',
            estimatedFare: 'R 85 - R 120',
            estimatedTime: '8 min',
            icon: 'directions_car',
            color: theme.colorScheme.secondary,
            onTap: () {
              HapticFeedback.lightImpact();
              // Deep link to Uber app
            },
          ),
          const SizedBox(height: 12),
          TransportCardWidget(
            service: 'Bolt',
            estimatedFare: 'R 75 - R 110',
            estimatedTime: '6 min',
            icon: 'electric_bolt',
            color: const Color(0xFF34D186),
            onTap: () {
              HapticFeedback.lightImpact();
              // Deep link to Bolt app
            },
          ),
          const SizedBox(height: 24),
          Text(
            'Recent Destinations',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          _buildDestinationCard(
            theme,
            'Cape Town Stadium',
            'Green Point, Cape Town',
            'stadium',
          ),
          const SizedBox(height: 8),
          _buildDestinationCard(
            theme,
            'V&A Waterfront',
            'Victoria & Alfred Waterfront',
            'shopping_bag',
          ),
        ],
      ),
    );
  }

  Widget _buildStaysTab(ThemeData theme) {
    final stays = [
      {
        "name": "The Table Bay Hotel",
        "location": "V&A Waterfront, Cape Town",
        "price": "R 3,200",
        "rating": 4.8,
        "image": "https://images.unsplash.com/photo-1681300938609-37d2d7a44197",
        "semanticLabel":
            "Luxury hotel exterior with modern architecture and palm trees",
        "available": true,
      },
      {
        "name": "Radisson Blu Sandton",
        "location": "Sandton, Johannesburg",
        "price": "R 2,100",
        "rating": 4.6,
        "image": "https://images.unsplash.com/photo-1630142346495-8c0aa0c87842",
        "semanticLabel": "Contemporary hotel room with king bed and city view",
        "available": true,
      },
      {
        "name": "Camps Bay Retreat",
        "location": "Camps Bay, Cape Town",
        "price": "R 4,500",
        "rating": 4.9,
        "image":
            "https://img.rocket.new/generatedImages/rocket_gen_img_1e9356047-1766325401561.png",
        "semanticLabel": "Boutique hotel nestled in mountain with ocean views",
        "available": false,
      },
    ];

    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: stays.length,
        itemBuilder: (context, index) {
          final stay = stays[index];
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: StayCardWidget(
              stay: stay,
              onTap: () {
                HapticFeedback.lightImpact();
                // Navigate to stay details
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildFlightsTab(ThemeData theme) {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FlightSearchWidget(
            onSearch: (from, to, date) {
              HapticFeedback.lightImpact();
              // Perform flight search
            },
          ),
          const SizedBox(height: 24),
          Text(
            'Popular Routes',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          _buildRouteCard(
            theme,
            'Cape Town',
            'Johannesburg',
            'From R 1,200',
            'flight_takeoff',
          ),
          const SizedBox(height: 12),
          _buildRouteCard(
            theme,
            'Johannesburg',
            'Durban',
            'From R 950',
            'flight_takeoff',
          ),
          const SizedBox(height: 12),
          _buildRouteCard(
            theme,
            'Cape Town',
            'Durban',
            'From R 1,400',
            'flight_takeoff',
          ),
        ],
      ),
    );
  }

  Widget _buildDestinationCard(
    ThemeData theme,
    String name,
    String address,
    String iconName,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: theme.colorScheme.secondary,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  address,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          CustomIconWidget(
            iconName: 'chevron_right',
            color: theme.colorScheme.onSurfaceVariant,
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildRouteCard(
    ThemeData theme,
    String from,
    String to,
    String price,
    String iconName,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.secondary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: theme.colorScheme.secondary,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      from,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: CustomIconWidget(
                        iconName: 'arrow_forward',
                        color: theme.colorScheme.onSurfaceVariant,
                        size: 16,
                      ),
                    ),
                    Text(
                      to,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  price,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.secondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          CustomIconWidget(
            iconName: 'chevron_right',
            color: theme.colorScheme.onSurfaceVariant,
            size: 20,
          ),
        ],
      ),
    );
  }
}
