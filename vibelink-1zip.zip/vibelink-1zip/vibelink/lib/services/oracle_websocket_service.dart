import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

/// Oracle WebSocket Service for Real-Time Messaging
/// Connects to Oracle VPS WebSocket server for live chat and notifications
class OracleWebSocketService {
  static const String _wsUrl = String.fromEnvironment(
    'ORACLE_WS_URL',
    defaultValue: 'wss://your-oracle-vps.com/ws',
  );

  WebSocketChannel? _channel;
  StreamController<Map<String, dynamic>>? _messageController;
  bool _isConnected = false;
  String? _authToken;

  /// Get message stream
  Stream<Map<String, dynamic>>? get messageStream => _messageController?.stream;

  /// Check if connected
  bool get isConnected => _isConnected;

  /// Connect to WebSocket server
  Future<void> connect(String authToken) async {
    if (_isConnected) {
      return;
    }

    _authToken = authToken;
    _messageController = StreamController<Map<String, dynamic>>.broadcast();

    try {
      final uri = Uri.parse('$_wsUrl?token=$authToken');
      _channel = WebSocketChannel.connect(uri);

      _channel!.stream.listen(
        (data) {
          try {
            final message = json.decode(data as String);
            _messageController?.add(message);
          } catch (e) {
            print('WebSocket message parse error: $e');
          }
        },
        onError: (error) {
          print('WebSocket error: $error');
          _handleDisconnect();
        },
        onDone: () {
          print('WebSocket connection closed');
          _handleDisconnect();
        },
      );

      _isConnected = true;
      print('WebSocket connected successfully');
    } catch (e) {
      print('WebSocket connection failed: $e');
      _handleDisconnect();
      rethrow;
    }
  }

  /// Send message through WebSocket
  void sendMessage(Map<String, dynamic> message) {
    if (!_isConnected || _channel == null) {
      throw Exception('WebSocket not connected');
    }

    try {
      _channel!.sink.add(json.encode(message));
    } catch (e) {
      print('Failed to send WebSocket message: $e');
      rethrow;
    }
  }

  /// Send chat message
  void sendChatMessage({
    required int conversationId,
    required String message,
    String? mediaUrl,
  }) {
    sendMessage({
      'type': 'chat_message',
      'conversation_id': conversationId,
      'message': message,
      'media_url': mediaUrl,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// Send typing indicator
  void sendTypingIndicator(int conversationId, bool isTyping) {
    sendMessage({
      'type': 'typing',
      'conversation_id': conversationId,
      'is_typing': isTyping,
    });
  }

  /// Subscribe to notification updates
  void subscribeToNotifications() {
    sendMessage({
      'type': 'subscribe_notifications',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// Unsubscribe from notification updates
  void unsubscribeFromNotifications() {
    sendMessage({
      'type': 'unsubscribe_notifications',
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  /// Join conversation room
  void joinConversation(int conversationId) {
    sendMessage({
      'type': 'join_conversation',
      'conversation_id': conversationId,
    });
  }

  /// Leave conversation room
  void leaveConversation(int conversationId) {
    sendMessage({
      'type': 'leave_conversation',
      'conversation_id': conversationId,
    });
  }

  /// Handle disconnection
  void _handleDisconnect() {
    _isConnected = false;
    _channel = null;
  }

  /// Disconnect from WebSocket
  Future<void> disconnect() async {
    if (_channel != null) {
      await _channel!.sink.close();
      _channel = null;
    }

    await _messageController?.close();
    _messageController = null;
    _isConnected = false;
  }

  /// Reconnect to WebSocket
  Future<void> reconnect() async {
    await disconnect();
    if (_authToken != null) {
      await connect(_authToken!);
    }
  }
}
