import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/oracle_api_service.dart';

class OrganizerAnalyticsScreen extends StatefulWidget {
  const OrganizerAnalyticsScreen({super.key});

  @override
  State<OrganizerAnalyticsScreen> createState() =>
      _OrganizerAnalyticsScreenState();
}

class _OrganizerAnalyticsScreenState extends State<OrganizerAnalyticsScreen> {
  bool _isLoading = true;
  Map<String, dynamic>? _analyticsData;
  String _selectedDateRange = '30d'; // 7d, 30d, 90d, 1y

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  Future<void> _loadAnalytics() async {
    setState(() => _isLoading = true);
    try {
      final data = await OracleApiService.getOrganizerAnalytics(
        dateRange: _selectedDateRange,
      );
      setState(() => _analyticsData = data);
    } catch (e) {
      print('Failed to load analytics: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _changeDateRange(String range) {
    if (_selectedDateRange != range) {
      setState(() => _selectedDateRange = range);
      _loadAnalytics();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            size: 6.w,
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Organizer Analytics',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'refresh',
              size: 6.w,
              color: theme.colorScheme.onSurface,
            ),
            onPressed: _loadAnalytics,
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(
                color: theme.colorScheme.primary,
              ),
            )
          : RefreshIndicator(
              onRefresh: _loadAnalytics,
              child: ListView(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                children: [
                  // Date range selector
                  _buildDateRangeSelector(theme),
                  SizedBox(height: 2.h),

                  // Key metrics cards
                  _buildKeyMetrics(theme),
                  SizedBox(height: 2.h),

                  // Revenue chart
                  _buildRevenueChart(theme),
                  SizedBox(height: 2.h),

                  // Ticket sales chart
                  _buildTicketSalesChart(theme),
                  SizedBox(height: 2.h),

                  // Event distribution pie chart
                  _buildEventDistributionChart(theme),
                  SizedBox(height: 2.h),

                  // Booking analytics
                  _buildBookingAnalytics(theme),
                  SizedBox(height: 2.h),

                  // Customer insights
                  _buildCustomerInsights(theme),
                  SizedBox(height: 2.h),

                  // Performance trends
                  _buildPerformanceTrends(theme),
                ],
              ),
            ),
    );
  }

  Widget _buildDateRangeSelector(ThemeData theme) {
    final ranges = [
      {'value': '7d', 'label': '7 Days'},
      {'value': '30d', 'label': '30 Days'},
      {'value': '90d', 'label': '90 Days'},
      {'value': '1y', 'label': '1 Year'},
    ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        children: ranges.map((range) {
          final isSelected = _selectedDateRange == range['value'];
          return Expanded(
            child: GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                _changeDateRange(range['value'] as String);
              },
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 1.w),
                padding: EdgeInsets.symmetric(vertical: 1.h),
                decoration: BoxDecoration(
                  color: isSelected
                      ? theme.colorScheme.primary
                      : theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? theme.colorScheme.primary
                        : theme.colorScheme.outline.withValues(alpha: 0.2),
                  ),
                ),
                child: Text(
                  range['label'] as String,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isSelected
                        ? theme.colorScheme.onPrimary
                        : theme.colorScheme.onSurface,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildKeyMetrics(ThemeData theme) {
    final metrics =
        _analyticsData?['key_metrics'] ??
        {
          'total_revenue': 'R 284,450',
          'total_tickets_sold': 3247,
          'total_events': 18,
          'avg_ticket_price': 'R 876',
          'revenue_growth': '+24.5%',
          'ticket_growth': '+18.2%',
        };

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Key Metrics',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 1.5.h),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 2.w,
            crossAxisSpacing: 2.w,
            childAspectRatio: 1.5,
            children: [
              _buildMetricCard(
                theme,
                'Total Revenue',
                metrics['total_revenue'].toString(),
                metrics['revenue_growth'].toString(),
                Icons.attach_money,
                AppTheme.successLight,
              ),
              _buildMetricCard(
                theme,
                'Tickets Sold',
                metrics['total_tickets_sold'].toString(),
                metrics['ticket_growth'].toString(),
                Icons.confirmation_number,
                AppTheme.secondaryLight,
              ),
              _buildMetricCard(
                theme,
                'Total Events',
                metrics['total_events'].toString(),
                null,
                Icons.event,
                AppTheme.accentLight,
              ),
              _buildMetricCard(
                theme,
                'Avg Ticket Price',
                metrics['avg_ticket_price'].toString(),
                null,
                Icons.local_offer,
                const Color(0xFF8B5CF6),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard(
    ThemeData theme,
    String label,
    String value,
    String? growth,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              if (growth != null)
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 2.w,
                    vertical: 0.5.h,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.successLight.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    growth,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: AppTheme.successLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRevenueChart(ThemeData theme) {
    final revenueData =
        _analyticsData?['revenue_by_month'] ??
        [
          {'month': 'Jan', 'revenue': 45000},
          {'month': 'Feb', 'revenue': 52000},
          {'month': 'Mar', 'revenue': 48000},
          {'month': 'Apr', 'revenue': 61000},
          {'month': 'May', 'revenue': 58000},
          {'month': 'Jun', 'revenue': 72000},
        ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Revenue Trends',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: AppTheme.successLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.trending_up,
                      size: 16,
                      color: AppTheme.successLight,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      '+24.5%',
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: AppTheme.successLight,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 25.h,
            child: LineChart(
              LineChartData(
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 20000,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: theme.colorScheme.outline.withValues(alpha: 0.2),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          'R${(value / 1000).toInt()}k',
                          style: theme.textTheme.labelSmall,
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= 0 &&
                            value.toInt() < revenueData.length) {
                          return Text(
                            revenueData[value.toInt()]['month'],
                            style: theme.textTheme.labelSmall,
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: List.generate(
                      revenueData.length,
                      (index) => FlSpot(
                        index.toDouble(),
                        revenueData[index]['revenue'].toDouble(),
                      ),
                    ),
                    isCurved: true,
                    color: theme.colorScheme.secondary,
                    barWidth: 3,
                    dotData: const FlDotData(show: true),
                    belowBarData: BarAreaData(
                      show: true,
                      color: theme.colorScheme.secondary.withValues(alpha: 0.1),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTicketSalesChart(ThemeData theme) {
    final salesData =
        _analyticsData?['ticket_sales_by_event'] ??
        [
          {'event': 'Summer Fest', 'sold': 450, 'total': 500},
          {'event': 'Jazz Night', 'sold': 280, 'total': 300},
          {'event': 'Food Fair', 'sold': 890, 'total': 1000},
          {'event': 'Art Expo', 'sold': 320, 'total': 400},
        ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ticket Sales by Event',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          SizedBox(
            height: 25.h,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 1000,
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        return Text(
                          value.toInt().toString(),
                          style: theme.textTheme.labelSmall,
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        if (value.toInt() >= 0 &&
                            value.toInt() < salesData.length) {
                          return Padding(
                            padding: EdgeInsets.only(top: 1.h),
                            child: Text(
                              salesData[value.toInt()]['event']
                                  .toString()
                                  .split(' ')[0],
                              style: theme.textTheme.labelSmall,
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                gridData: FlGridData(show: true, drawVerticalLine: false),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(
                  salesData.length,
                  (index) => BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: salesData[index]['sold'].toDouble(),
                        color: theme.colorScheme.secondary,
                        width: 20,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventDistributionChart(ThemeData theme) {
    final distributionData =
        _analyticsData?['event_distribution'] ??
        [
          {'category': 'Music', 'count': 8, 'color': AppTheme.secondaryLight},
          {'category': 'Food', 'count': 5, 'color': AppTheme.accentLight},
          {'category': 'Art', 'count': 3, 'color': AppTheme.successLight},
          {'category': 'Sports', 'count': 2, 'color': const Color(0xFF8B5CF6)},
        ];

    final total = distributionData.fold<int>(
      0,
      (sum, item) => sum + (item['count'] as int),
    );

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Event Distribution',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              SizedBox(
                width: 40.w,
                height: 40.w,
                child: PieChart(
                  PieChartData(
                    sectionsSpace: 2,
                    centerSpaceRadius: 15.w,
                    sections: distributionData.map((item) {
                      final percentage = ((item['count'] as int) / total * 100)
                          .toStringAsFixed(1);
                      return PieChartSectionData(
                        value: (item['count'] as int).toDouble(),
                        title: '$percentage%',
                        color: item['color'] as Color,
                        radius: 12.w,
                        titleStyle: theme.textTheme.labelSmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: distributionData.map((item) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 1.h),
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: item['color'] as Color,
                              shape: BoxShape.circle,
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            '${item['category']} (${item['count']})',
                            style: theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBookingAnalytics(ThemeData theme) {
    final bookingStats =
        _analyticsData?['booking_stats'] ??
        {
          'total_bookings': 1247,
          'pending': 23,
          'confirmed': 1189,
          'cancelled': 35,
          'avg_booking_value': 'R 2,284',
          'conversion_rate': '87.2%',
        };

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Booking Analytics',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  theme,
                  'Total',
                  bookingStats['total_bookings'].toString(),
                  Icons.book_online,
                  AppTheme.secondaryLight,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  theme,
                  'Confirmed',
                  bookingStats['confirmed'].toString(),
                  Icons.check_circle,
                  AppTheme.successLight,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  theme,
                  'Pending',
                  bookingStats['pending'].toString(),
                  Icons.pending,
                  AppTheme.accentLight,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  theme,
                  'Cancelled',
                  bookingStats['cancelled'].toString(),
                  Icons.cancel,
                  AppTheme.errorLight,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Divider(color: theme.colorScheme.outline.withValues(alpha: 0.2)),
          SizedBox(height: 1.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Text(
                    bookingStats['avg_booking_value'].toString(),
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'Avg Booking Value',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              Container(
                width: 1,
                height: 5.h,
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
              Column(
                children: [
                  Text(
                    bookingStats['conversion_rate'].toString(),
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: AppTheme.successLight,
                    ),
                  ),
                  Text(
                    'Conversion Rate',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(
    ThemeData theme,
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomerInsights(ThemeData theme) {
    final insights =
        _analyticsData?['customer_insights'] ??
        {
          'total_customers': 2847,
          'new_customers': 342,
          'returning_customers': 2505,
          'customer_retention': '88.0%',
          'avg_events_per_customer': '3.2',
        };

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Customer Insights',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          _buildInsightRow(
            theme,
            'Total Customers',
            insights['total_customers'].toString(),
            Icons.people,
          ),
          _buildInsightRow(
            theme,
            'New Customers',
            insights['new_customers'].toString(),
            Icons.person_add,
          ),
          _buildInsightRow(
            theme,
            'Returning Customers',
            insights['returning_customers'].toString(),
            Icons.repeat,
          ),
          _buildInsightRow(
            theme,
            'Customer Retention',
            insights['customer_retention'].toString(),
            Icons.trending_up,
          ),
          _buildInsightRow(
            theme,
            'Avg Events per Customer',
            insights['avg_events_per_customer'].toString(),
            Icons.event_available,
          ),
        ],
      ),
    );
  }

  Widget _buildInsightRow(
    ThemeData theme,
    String label,
    String value,
    IconData icon,
  ) {
    return Padding(
      padding: EdgeInsets.only(bottom: 1.5.h),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.onSurfaceVariant),
          SizedBox(width: 3.w),
          Expanded(child: Text(label, style: theme.textTheme.bodyMedium)),
          Text(
            value,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPerformanceTrends(ThemeData theme) {
    final trends =
        _analyticsData?['performance_trends'] ??
        [
          {
            'metric': 'Average Event Attendance',
            'value': '284',
            'change': '+12.5%',
            'positive': true,
          },
          {
            'metric': 'Ticket Sell-Through Rate',
            'value': '89.2%',
            'change': '+5.3%',
            'positive': true,
          },
          {
            'metric': 'Customer Satisfaction',
            'value': '4.7/5.0',
            'change': '+0.2',
            'positive': true,
          },
          {
            'metric': 'Event Cancellation Rate',
            'value': '2.1%',
            'change': '-0.8%',
            'positive': true,
          },
        ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Performance Trends',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          ...trends.map((trend) {
            final isPositive = trend['positive'] as bool;
            return Container(
              margin: EdgeInsets.only(bottom: 1.5.h),
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          trend['metric'] as String,
                          style: theme.textTheme.bodyMedium,
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          trend['value'] as String,
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 2.w,
                      vertical: 0.5.h,
                    ),
                    decoration: BoxDecoration(
                      color:
                          (isPositive
                                  ? AppTheme.successLight
                                  : AppTheme.errorLight)
                              .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isPositive ? Icons.trending_up : Icons.trending_down,
                          size: 16,
                          color: isPositive
                              ? AppTheme.successLight
                              : AppTheme.errorLight,
                        ),
                        SizedBox(width: 1.w),
                        Text(
                          trend['change'] as String,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: isPositive
                                ? AppTheme.successLight
                                : AppTheme.errorLight,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
