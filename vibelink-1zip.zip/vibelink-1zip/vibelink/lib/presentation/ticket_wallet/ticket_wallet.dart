import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pretty_qr_code/pretty_qr_code.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/oracle_api_service.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/ticket_card_widget.dart';

/// Ticket Wallet Screen - Displays user's event tickets with QR codes
class TicketWallet extends StatefulWidget {
  const TicketWallet({super.key});

  @override
  State<TicketWallet> createState() => _TicketWalletState();
}

class _TicketWalletState extends State<TicketWallet>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  List<Map<String, dynamic>> _tickets = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadTickets();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadTickets() async {
    setState(() => _isLoading = true);

    try {
      final tickets = await OracleApiService.getTicketWallet();
      setState(() {
        _tickets = tickets;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load tickets: ${e.toString()}')),
        );
      }
    }
  }

  List<Map<String, dynamic>> get _upcomingTickets {
    return _tickets
        .where(
          (t) =>
              DateTime.parse(t['event_date']).isAfter(DateTime.now()) &&
              t['status'] == 'active',
        )
        .toList();
  }

  List<Map<String, dynamic>> get _pastTickets {
    return _tickets
        .where((t) => DateTime.parse(t['event_date']).isBefore(DateTime.now()))
        .toList();
  }

  List<Map<String, dynamic>> get _transferredTickets {
    return _tickets.where((t) => t['status'] == 'transferred').toList();
  }

  void _showTicketDetails(Map<String, dynamic> ticket) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildTicketDetailModal(ticket),
    );
  }

  Widget _buildTicketDetailModal(Map<String, dynamic> ticket) {
    final theme = Theme.of(context);

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'close',
                    size: 6.w,
                    color: theme.colorScheme.onSurface,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  'Ticket Details',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(width: 12.w),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.all(4.w),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: theme.colorScheme.shadow,
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        PrettyQrView.data(
                          data: ticket['qr_code'] ?? ticket['ticket_id'],
                          decoration: const PrettyQrDecoration(
                            shape: PrettyQrSmoothSymbol(
                              color: Color(0xFF1A1A1A),
                            ),
                          ),
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          ticket['ticket_id'],
                          style: theme.textTheme.bodySmall?.copyWith(
                            fontFamily: 'monospace',
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 3.h),
                  _buildDetailRow(
                    'Event',
                    ticket['event_title'],
                    Icons.event,
                    theme,
                  ),
                  _buildDetailRow(
                    'Date',
                    ticket['event_date'],
                    Icons.calendar_today,
                    theme,
                  ),
                  _buildDetailRow(
                    'Location',
                    ticket['event_location'],
                    Icons.location_on,
                    theme,
                  ),
                  _buildDetailRow(
                    'Quantity',
                    '${ticket['quantity']} ticket(s)',
                    Icons.confirmation_number,
                    theme,
                  ),
                  _buildDetailRow(
                    'Status',
                    ticket['status'].toString().toUpperCase(),
                    Icons.check_circle,
                    theme,
                  ),
                  SizedBox(height: 3.h),
                  if (ticket['status'] == 'active')
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => _transferTicket(ticket),
                        icon: const Icon(Icons.send),
                        label: const Text('Transfer Ticket'),
                      ),
                    ),
                  if (ticket['status'] == 'active') SizedBox(height: 1.h),
                  if (ticket['status'] == 'active')
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _downloadTicket(ticket),
                        icon: const Icon(Icons.download),
                        label: const Text('Download'),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(
    String label,
    String value,
    IconData icon,
    ThemeData theme,
  ) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      child: Row(
        children: [
          Icon(icon, size: 5.w, color: theme.colorScheme.secondary),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  value,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _transferTicket(Map<String, dynamic> ticket) {
    Navigator.pop(context);
    HapticFeedback.lightImpact();

    final emailController = TextEditingController();
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Transfer Ticket'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Enter the email address of the recipient',
              style: theme.textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Recipient Email',
                hintText: 'email@example.com',
              ),
              keyboardType: TextInputType.emailAddress,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (emailController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.transferTicket(
                    ticketId: ticket['ticket_id'],
                    recipientEmail: emailController.text,
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Ticket transferred successfully!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                    _loadTickets();
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Transfer failed: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Transfer'),
          ),
        ],
      ),
    );
  }

  void _downloadTicket(Map<String, dynamic> ticket) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Ticket downloaded for offline access'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: CustomAppBar(
        variant: CustomAppBarVariant.detail,
        showBackButton: true,
        title: 'My Tickets',
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.colorScheme.outline),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: theme.colorScheme.secondary,
                borderRadius: BorderRadius.circular(10),
              ),
              labelColor: theme.colorScheme.onSecondary,
              unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
              tabs: const [
                Tab(text: 'Upcoming'),
                Tab(text: 'Past'),
                Tab(text: 'Transferred'),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      color: theme.colorScheme.secondary,
                    ),
                  )
                : TabBarView(
                    controller: _tabController,
                    children: [
                      _buildTicketList(_upcomingTickets),
                      _buildTicketList(_pastTickets),
                      _buildTicketList(_transferredTickets),
                    ],
                  ),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: 4,
        onTap: (index) {
          if (index != 4) {
            Navigator.pushReplacementNamed(
              context,
              CustomBottomBarItem.values[index].route,
            );
          }
        },
      ),
    );
  }

  Widget _buildTicketList(List<Map<String, dynamic>> tickets) {
    if (tickets.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.confirmation_number_outlined,
              size: 20.w,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
            SizedBox(height: 2.h),
            Text(
              'No tickets found',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      itemCount: tickets.length,
      itemBuilder: (context, index) {
        return TicketCardWidget(
          ticket: tickets[index],
          onTap: () => _showTicketDetails(tickets[index]),
        );
      },
    );
  }
}
