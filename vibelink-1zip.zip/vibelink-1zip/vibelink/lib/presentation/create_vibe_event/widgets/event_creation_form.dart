import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import './media_attachment_section.dart';

/// Event creation form widget with comprehensive event details input
class EventCreationForm extends StatefulWidget {
  final Function(Map<String, dynamic>) onEventCreated;

  const EventCreationForm({super.key, required this.onEventCreated});

  @override
  State<EventCreationForm> createState() => _EventCreationFormState();
}

class _EventCreationFormState extends State<EventCreationForm> {
  final TextEditingController _titleController = TextEditingController();
  final quill.QuillController _descriptionController =
      quill.QuillController.basic();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _capacityController = TextEditingController();

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String? _selectedCategory;
  LatLng? _selectedLocation;
  final List<XFile> _eventMedia = [];
  final List<String> _selectedVibeTags = [];

  final List<String> _categories = [
    'Music & Concerts',
    'Food & Dining',
    'Sports & Fitness',
    'Arts & Culture',
    'Business & Networking',
    'Technology',
    'Travel & Adventure',
    'Wellness & Health',
    'Education & Learning',
    'Entertainment',
  ];

  final List<String> _vibeTags = [
    'Energetic',
    'Relaxed',
    'Professional',
    'Casual',
    'Exclusive',
    'Family-Friendly',
    'Outdoor',
    'Indoor',
    'Night Life',
    'Day Event',
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _priceController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  void _handleMediaSelected(List<XFile> media) {
    setState(() {
      _eventMedia.addAll(media);
    });
  }

  void _removeMedia(int index) {
    setState(() {
      _eventMedia.removeAt(index);
    });
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  void _showLocationPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildLocationPickerModal(),
    );
  }

  void _toggleVibeTag(String tag) {
    setState(() {
      _selectedVibeTags.contains(tag)
          ? _selectedVibeTags.remove(tag)
          : _selectedVibeTags.add(tag);
    });
  }

  bool _validateForm() {
    if (_titleController.text.trim().isEmpty) {
      _showError('Please enter event title');
      return false;
    }
    if (_selectedDate == null) {
      _showError('Please select event date');
      return false;
    }
    if (_selectedTime == null) {
      _showError('Please select event time');
      return false;
    }
    if (_locationController.text.trim().isEmpty) {
      _showError('Please enter event location');
      return false;
    }
    if (_selectedCategory == null) {
      _showError('Please select event category');
      return false;
    }
    if (_priceController.text.trim().isEmpty) {
      _showError('Please enter ticket price');
      return false;
    }
    if (_capacityController.text.trim().isEmpty) {
      _showError('Please enter event capacity');
      return false;
    }
    return true;
  }

  void _showError(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _submitEvent() {
    if (!_validateForm()) return;

    final eventData = {
      'title': _titleController.text.trim(),
      'description': _descriptionController.document.toPlainText().trim(),
      'date': _selectedDate!.toIso8601String(),
      'time': '${_selectedTime!.hour}:${_selectedTime!.minute}',
      'location': _locationController.text.trim(),
      'coordinates': _selectedLocation != null
          ? {
              'latitude': _selectedLocation!.latitude,
              'longitude': _selectedLocation!.longitude,
            }
          : null,
      'category': _selectedCategory,
      'price': double.tryParse(_priceController.text.trim()) ?? 0.0,
      'capacity': int.tryParse(_capacityController.text.trim()) ?? 0,
      'media': _eventMedia.map((file) => file.path).toList(),
      'vibeTags': _selectedVibeTags,
      'createdAt': DateTime.now().toIso8601String(),
    };

    widget.onEventCreated(eventData);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTextField(
            controller: _titleController,
            label: 'Event Title',
            hint: 'Enter event name',
            theme: theme,
          ),
          SizedBox(height: 2.h),
          _buildDescriptionEditor(theme),
          SizedBox(height: 2.h),
          _buildDateTimePickers(theme),
          SizedBox(height: 2.h),
          _buildLocationField(theme),
          SizedBox(height: 2.h),
          _buildCategoryDropdown(theme),
          SizedBox(height: 2.h),
          _buildPricingFields(theme),
          SizedBox(height: 2.h),
          _buildVibeTagsSection(theme),
          SizedBox(height: 2.h),
          if (_eventMedia.isNotEmpty) _buildMediaPreview(theme),
          SizedBox(height: 2.h),
          MediaAttachmentSection(
            onMediaSelected: _handleMediaSelected,
            onAudioRecorded: (_) {},
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required ThemeData theme,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    int maxLines = 1,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          TextField(
            controller: controller,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            maxLines: maxLines,
            style: theme.textTheme.bodyMedium,
            decoration: InputDecoration(hintText: hint),
          ),
        ],
      ),
    );
  }

  Widget _buildDescriptionEditor(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Event Description', style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          Container(
            height: 25.h,
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.colorScheme.outline),
            ),
            child: Column(
              children: [
                quill.QuillSimpleToolbar(controller: _descriptionController),
                Expanded(
                  child: quill.QuillEditor.basic(
                    controller: _descriptionController,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateTimePickers(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: _selectDate,
              child: Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: theme.colorScheme.outline),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'calendar_today',
                      color: theme.colorScheme.secondary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        _selectedDate != null
                            ? '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}'
                            : 'Select Date',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: _selectedDate != null
                              ? theme.colorScheme.onSurface
                              : theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: InkWell(
              onTap: _selectTime,
              child: Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: theme.colorScheme.outline),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'access_time',
                      color: theme.colorScheme.secondary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        _selectedTime != null
                            ? '${_selectedTime!.hour}:${_selectedTime!.minute.toString().padLeft(2, '0')}'
                            : 'Select Time',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: _selectedTime != null
                              ? theme.colorScheme.onSurface
                              : theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationField(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Event Location', style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          InkWell(
            onTap: _showLocationPicker,
            child: Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.colorScheme.outline),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'location_on',
                    color: theme.colorScheme.secondary,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      _locationController.text.isEmpty
                          ? 'Select location on map'
                          : _locationController.text,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: _locationController.text.isEmpty
                            ? theme.colorScheme.onSurfaceVariant
                            : theme.colorScheme.onSurface,
                      ),
                    ),
                  ),
                  CustomIconWidget(
                    iconName: 'arrow_forward_ios',
                    color: theme.colorScheme.onSurfaceVariant,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryDropdown(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Event Category', style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            initialValue: _selectedCategory,
            decoration: const InputDecoration(hintText: 'Select category'),
            items: _categories.map((category) {
              return DropdownMenuItem(value: category, child: Text(category));
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedCategory = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPricingFields(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ticket Price (ZAR)', style: theme.textTheme.titleSmall),
                SizedBox(height: 1.h),
                TextField(
                  controller: _priceController,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                      RegExp(r'^\d+\.?\d{0,2}'),
                    ),
                  ],
                  style: theme.textTheme.bodyMedium,
                  decoration: const InputDecoration(
                    hintText: 'R 0.00',
                    prefixText: 'R ',
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Capacity', style: theme.textTheme.titleSmall),
                SizedBox(height: 1.h),
                TextField(
                  controller: _capacityController,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  style: theme.textTheme.bodyMedium,
                  decoration: const InputDecoration(hintText: '0'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVibeTagsSection(ThemeData theme) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Vibe Tags', style: theme.textTheme.titleSmall),
          SizedBox(height: 1.h),
          Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _vibeTags.map((tag) {
              final isSelected = _selectedVibeTags.contains(tag);
              return FilterChip(
                label: Text(tag),
                selected: isSelected,
                onSelected: (selected) => _toggleVibeTag(tag),
                backgroundColor: theme.colorScheme.surface,
                selectedColor: theme.colorScheme.secondary.withValues(
                  alpha: 0.2,
                ),
                labelStyle: theme.textTheme.labelMedium?.copyWith(
                  color: isSelected
                      ? theme.colorScheme.secondary
                      : theme.colorScheme.onSurface,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildMediaPreview(ThemeData theme) {
    return Container(
      height: 20.h,
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _eventMedia.length,
        itemBuilder: (context, index) {
          return Container(
            width: 30.w,
            margin: EdgeInsets.only(right: 2.w),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CustomImageWidget(
                    imageUrl: _eventMedia[index].path,
                    width: 30.w,
                    height: 20.h,
                    fit: BoxFit.cover,
                    semanticLabel: 'Event media preview ${index + 1}',
                  ),
                ),
                Positioned(
                  top: 1.h,
                  right: 1.w,
                  child: InkWell(
                    onTap: () => _removeMedia(index),
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.error,
                        shape: BoxShape.circle,
                      ),
                      child: CustomIconWidget(
                        iconName: 'close',
                        color: theme.colorScheme.onError,
                        size: 16,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLocationPickerModal() {
    final theme = Theme.of(context);
    LatLng currentPosition = const LatLng(-26.2041, 28.0473);

    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.error,
                    ),
                  ),
                ),
                Text('Select Location', style: theme.textTheme.titleMedium),
                TextButton(
                  onPressed: () {
                    if (_selectedLocation != null) {
                      _locationController.text =
                          'Lat: ${_selectedLocation!.latitude.toStringAsFixed(4)}, Lng: ${_selectedLocation!.longitude.toStringAsFixed(4)}';
                      Navigator.pop(context);
                    }
                  },
                  child: Text(
                    'Done',
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: theme.colorScheme.secondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: currentPosition,
                zoom: 14,
              ),
              onTap: (position) {
                setState(() {
                  _selectedLocation = position;
                });
              },
              markers: _selectedLocation != null
                  ? {
                      Marker(
                        markerId: const MarkerId('selected_location'),
                        position: _selectedLocation!,
                      ),
                    }
                  : {},
            ),
          ),
        ],
      ),
    );
  }
}
