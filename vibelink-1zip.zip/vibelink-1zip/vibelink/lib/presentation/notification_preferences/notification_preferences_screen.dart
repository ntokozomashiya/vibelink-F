import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../services/oracle_api_service.dart';

class NotificationPreferencesScreen extends StatefulWidget {
  const NotificationPreferencesScreen({super.key});

  @override
  State<NotificationPreferencesScreen> createState() =>
      _NotificationPreferencesScreenState();
}

class _NotificationPreferencesScreenState
    extends State<NotificationPreferencesScreen> {
  bool _isLoading = true;
  Map<String, dynamic> _preferences = {};

  // Notification type preferences
  final Map<String, Map<String, dynamic>> _notificationTypes = {
    'messages': {
      'title': 'Messages',
      'subtitle': 'New messages and chat notifications',
      'icon': Icons.chat_bubble,
      'color': AppTheme.secondaryLight,
      'enabled': true,
      'frequency': 'instant',
      'push': true,
      'email': false,
    },
    'events': {
      'title': 'Events',
      'subtitle': 'Event updates, reminders, and invitations',
      'icon': Icons.event,
      'color': AppTheme.accentLight,
      'enabled': true,
      'frequency': 'instant',
      'push': true,
      'email': true,
    },
    'bookings': {
      'title': 'Bookings',
      'subtitle': 'Booking confirmations and travel updates',
      'icon': Icons.book_online,
      'color': AppTheme.successLight,
      'enabled': true,
      'frequency': 'instant',
      'push': true,
      'email': true,
    },
    'promotions': {
      'title': 'Promotions',
      'subtitle': 'Special offers, deals, and featured events',
      'icon': Icons.local_offer,
      'color': const Color(0xFF8B5CF6),
      'enabled': false,
      'frequency': 'weekly',
      'push': false,
      'email': true,
    },
  };

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await OracleApiService.getNotificationPreferences();
      setState(() {
        _preferences = prefs;
        // Update local state with fetched preferences
        prefs.forEach((key, value) {
          if (_notificationTypes.containsKey(key)) {
            _notificationTypes[key]!['enabled'] = value['enabled'] ?? true;
            _notificationTypes[key]!['frequency'] =
                value['frequency'] ?? 'instant';
            _notificationTypes[key]!['push'] = value['push'] ?? true;
            _notificationTypes[key]!['email'] = value['email'] ?? false;
          }
        });
      });
    } catch (e) {
      print('Failed to load notification preferences: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _updatePreference(
    String type,
    String field,
    dynamic value,
  ) async {
    setState(() {
      _notificationTypes[type]![field] = value;
    });

    try {
      await OracleApiService.updateNotificationPreferences(
        preferences: {type: _notificationTypes[type]!},
      );
      HapticFeedback.lightImpact();
    } catch (e) {
      print('Failed to update preference: $e');
      // Revert on error
      setState(() {
        _notificationTypes[type]![field] = !value;
      });
    }
  }

  void _showDetailModal(String type) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildDetailModal(type),
    );
  }

  Widget _buildDetailModal(String type) {
    final theme = Theme.of(context);
    final typeData = _notificationTypes[type]!;

    return Container(
      height: 65.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Modal header
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: theme.colorScheme.outline.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'arrow_back',
                    size: 6.w,
                    color: theme.colorScheme.onSurface,
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                Text(
                  '${typeData['title']} Settings',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(width: 12.w),
              ],
            ),
          ),
          // Modal content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Enable/Disable
                  _buildModalSection(
                    theme,
                    'Enable Notifications',
                    'Receive ${typeData['title'].toString().toLowerCase()} notifications',
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: typeData['enabled'] as bool,
                      onChanged: (value) {
                        _updatePreference(type, 'enabled', value);
                        Navigator.pop(context);
                      },
                      title: Text(
                        typeData['enabled'] as bool ? 'Enabled' : 'Disabled',
                        style: theme.textTheme.bodyMedium,
                      ),
                    ),
                  ),
                  SizedBox(height: 3.h),

                  // Frequency
                  if (typeData['enabled'] as bool)
                    _buildModalSection(
                      theme,
                      'Notification Frequency',
                      'How often you want to receive notifications',
                      Column(
                        children: [
                          _buildFrequencyOption(
                            theme,
                            type,
                            'instant',
                            'Instant',
                            'Receive notifications immediately',
                          ),
                          _buildFrequencyOption(
                            theme,
                            type,
                            'daily',
                            'Daily Digest',
                            'Once per day summary',
                          ),
                          _buildFrequencyOption(
                            theme,
                            type,
                            'weekly',
                            'Weekly Summary',
                            'Once per week summary',
                          ),
                        ],
                      ),
                    ),
                  if (typeData['enabled'] as bool) SizedBox(height: 3.h),

                  // Delivery channels
                  if (typeData['enabled'] as bool)
                    _buildModalSection(
                      theme,
                      'Delivery Channels',
                      'Where you want to receive notifications',
                      Column(
                        children: [
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            value: typeData['push'] as bool,
                            onChanged: (value) {
                              _updatePreference(type, 'push', value);
                            },
                            title: Row(
                              children: [
                                Icon(
                                  Icons.notifications,
                                  size: 20,
                                  color: theme.colorScheme.onSurface,
                                ),
                                SizedBox(width: 3.w),
                                Text(
                                  'Push Notifications',
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ],
                            ),
                            subtitle: Padding(
                              padding: EdgeInsets.only(left: 8.w),
                              child: Text(
                                'On your device',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 1.h),
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            value: typeData['email'] as bool,
                            onChanged: (value) {
                              _updatePreference(type, 'email', value);
                            },
                            title: Row(
                              children: [
                                Icon(
                                  Icons.email,
                                  size: 20,
                                  color: theme.colorScheme.onSurface,
                                ),
                                SizedBox(width: 3.w),
                                Text(
                                  'Email Notifications',
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ],
                            ),
                            subtitle: Padding(
                              padding: EdgeInsets.only(left: 8.w),
                              child: Text(
                                'To your email address',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModalSection(
    ThemeData theme,
    String title,
    String subtitle,
    Widget content,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          subtitle,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.5.h),
        content,
      ],
    );
  }

  Widget _buildFrequencyOption(
    ThemeData theme,
    String type,
    String value,
    String label,
    String description,
  ) {
    final isSelected = _notificationTypes[type]!['frequency'] == value;

    return InkWell(
      onTap: () {
        _updatePreference(type, 'frequency', value);
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 1.h),
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: isSelected
              ? theme.colorScheme.primary.withValues(alpha: 0.05)
              : Colors.transparent,
          border: Border.all(
            color: isSelected
                ? theme.colorScheme.primary
                : theme.colorScheme.outline.withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected
                  ? theme.colorScheme.primary
                  : theme.colorScheme.onSurfaceVariant,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: isSelected
                          ? FontWeight.w600
                          : FontWeight.w500,
                    ),
                  ),
                  Text(
                    description,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            size: 6.w,
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Notification Preferences',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(
                color: theme.colorScheme.primary,
              ),
            )
          : ListView(
              padding: EdgeInsets.symmetric(vertical: 2.h),
              children: [
                // Header info
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w),
                  child: Text(
                    'Customize your notification preferences for different types of activities. Tap on each category to configure detailed settings.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                SizedBox(height: 3.h),

                // Notification type cards
                ..._notificationTypes.entries.map((entry) {
                  final type = entry.key;
                  final data = entry.value;

                  return _buildNotificationTypeCard(theme, type, data);
                }),
              ],
            ),
    );
  }

  Widget _buildNotificationTypeCard(
    ThemeData theme,
    String type,
    Map<String, dynamic> data,
  ) {
    final enabled = data['enabled'] as bool;
    final frequency = data['frequency'] as String;
    final push = data['push'] as bool;
    final email = data['email'] as bool;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        children: [
          // Main toggle
          SwitchListTile(
            contentPadding: EdgeInsets.symmetric(
              horizontal: 4.w,
              vertical: 1.h,
            ),
            value: enabled,
            onChanged: (value) => _updatePreference(type, 'enabled', value),
            secondary: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: (data['color'] as Color).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                data['icon'] as IconData,
                color: data['color'] as Color,
                size: 24,
              ),
            ),
            title: Text(
              data['title'] as String,
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            subtitle: Text(
              data['subtitle'] as String,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),

          // Details section (when enabled)
          if (enabled)
            Divider(
              height: 1,
              color: theme.colorScheme.outline.withValues(alpha: 0.2),
            ),
          if (enabled)
            InkWell(
              onTap: () => _showDetailModal(type),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.schedule,
                                size: 16,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                              SizedBox(width: 2.w),
                              Text(
                                _getFrequencyLabel(frequency),
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 0.5.h),
                          Row(
                            children: [
                              if (push)
                                Icon(
                                  Icons.notifications,
                                  size: 16,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              if (push) SizedBox(width: 1.w),
                              if (email)
                                Icon(
                                  Icons.email,
                                  size: 16,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              if (email) SizedBox(width: 1.w),
                              Text(
                                _getChannelsLabel(push, email),
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.chevron_right,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _getFrequencyLabel(String frequency) {
    switch (frequency) {
      case 'instant':
        return 'Instant notifications';
      case 'daily':
        return 'Daily digest';
      case 'weekly':
        return 'Weekly summary';
      default:
        return 'Instant notifications';
    }
  }

  String _getChannelsLabel(bool push, bool email) {
    if (push && email) return 'Push & Email';
    if (push) return 'Push only';
    if (email) return 'Email only';
    return 'No channels';
  }
}
