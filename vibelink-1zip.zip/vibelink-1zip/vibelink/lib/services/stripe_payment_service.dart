import 'package:dio/dio.dart';

/// Stripe Payment Service
/// Handles all Stripe payment processing via REST API
class StripePaymentService {
  static const String _stripeApiUrl = 'https://api.stripe.com/v1';
  static const String _stripePublishableKey = String.fromEnvironment(
    'STRIPE_PUBLISHABLE_KEY',
    defaultValue: '',
  );
  static const String _stripeSecretKey = String.fromEnvironment(
    'STRIPE_SECRET_KEY',
    defaultValue: '',
  );

  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: _stripeApiUrl,
      headers: {
        'Authorization': 'Bearer $_stripeSecretKey',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
    ),
  );

  /// Validate environment variables
  static void validateConfiguration() {
    if (_stripePublishableKey.isEmpty) {
      throw Exception('STRIPE_PUBLISHABLE_KEY is not configured.');
    }
    if (_stripeSecretKey.isEmpty) {
      throw Exception('STRIPE_SECRET_KEY is not configured.');
    }
  }

  /// Create Payment Intent for ticket purchase
  static Future<Map<String, dynamic>> createPaymentIntent({
    required double amount,
    required String currency,
    required String description,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final response = await _dio.post(
        '/payment_intents',
        data: {
          'amount': (amount * 100).toInt(), // Convert to cents
          'currency': currency.toLowerCase(),
          'description': description,
          'metadata': metadata ?? {},
          'automatic_payment_methods[enabled]': true,
        },
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw _handleStripeError(e);
    }
  }

  /// Process ticket purchase payment
  static Future<Map<String, dynamic>> processTicketPayment({
    required int eventId,
    required String eventTitle,
    required int quantity,
    required double ticketPrice,
    required double platformFee,
    String currency = 'usd',
  }) async {
    final totalAmount = (ticketPrice * quantity) + platformFee;

    final paymentIntent = await createPaymentIntent(
      amount: totalAmount,
      currency: currency,
      description: 'Ticket purchase: $eventTitle (x$quantity)',
      metadata: {
        'event_id': eventId.toString(),
        'quantity': quantity.toString(),
        'ticket_price': ticketPrice.toString(),
        'platform_fee': platformFee.toString(),
        'type': 'ticket_purchase',
      },
    );

    return {
      'payment_intent_id': paymentIntent['id'],
      'client_secret': paymentIntent['client_secret'],
      'amount': totalAmount,
      'status': paymentIntent['status'],
    };
  }

  /// Process event booking payment
  static Future<Map<String, dynamic>> processBookingPayment({
    required int bookingId,
    required String bookingType,
    required double amount,
    required double platformFee,
    String currency = 'usd',
  }) async {
    final totalAmount = amount + platformFee;

    final paymentIntent = await createPaymentIntent(
      amount: totalAmount,
      currency: currency,
      description: 'Booking: $bookingType',
      metadata: {
        'booking_id': bookingId.toString(),
        'booking_type': bookingType,
        'base_amount': amount.toString(),
        'platform_fee': platformFee.toString(),
        'type': 'booking_payment',
      },
    );

    return {
      'payment_intent_id': paymentIntent['id'],
      'client_secret': paymentIntent['client_secret'],
      'amount': totalAmount,
      'status': paymentIntent['status'],
    };
  }

  /// Confirm payment with payment method
  static Future<Map<String, dynamic>> confirmPayment({
    required String paymentIntentId,
    required String paymentMethodId,
  }) async {
    try {
      final response = await _dio.post(
        '/payment_intents/$paymentIntentId/confirm',
        data: {'payment_method': paymentMethodId},
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw _handleStripeError(e);
    }
  }

  /// Create payment method (card)
  static Future<Map<String, dynamic>> createPaymentMethod({
    required String cardNumber,
    required String expMonth,
    required String expYear,
    required String cvc,
  }) async {
    try {
      final response = await _dio.post(
        '/payment_methods',
        data: {
          'type': 'card',
          'card[number]': cardNumber,
          'card[exp_month]': expMonth,
          'card[exp_year]': expYear,
          'card[cvc]': cvc,
        },
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw _handleStripeError(e);
    }
  }

  /// Retrieve payment intent status
  static Future<Map<String, dynamic>> getPaymentIntent(
    String paymentIntentId,
  ) async {
    try {
      final response = await _dio.get('/payment_intents/$paymentIntentId');
      return response.data as Map<String, dynamic>;
    } on DioException catch (e) {
      throw _handleStripeError(e);
    }
  }

  /// Calculate platform fee (5% of ticket/booking price)
  static double calculatePlatformFee(double baseAmount) {
    return (baseAmount * 0.05).roundToDouble();
  }

  /// Handle Stripe API errors
  static Exception _handleStripeError(DioException error) {
    if (error.response?.data != null) {
      final errorData = error.response!.data;
      final message = errorData['error']?['message'] ?? 'Payment failed';
      return Exception('Stripe Error: $message');
    }

    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return Exception('Payment timeout. Please try again.');
      case DioExceptionType.connectionError:
        return Exception('Connection error. Check your internet.');
      default:
        return Exception('Payment failed. Please try again.');
    }
  }
}
