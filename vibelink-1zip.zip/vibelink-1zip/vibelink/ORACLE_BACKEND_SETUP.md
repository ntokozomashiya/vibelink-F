# Oracle VPS Backend Setup Guide

## Overview
This document provides the database schemas and API specifications for deploying the VibeLink backend on Oracle VPS with Oracle Database.

## Database Schemas (Oracle SQL)

### 1. Users Table
```sql
CREATE TABLE users (
  user_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email VARCHAR2(255) UNIQUE NOT NULL,
  password_hash VARCHAR2(255) NOT NULL,
  full_name VARCHAR2(255) NOT NULL,
  phone VARCHAR2(50),
  bio VARCHAR2(1000),
  avatar_url VARCHAR2(500),
  is_organizer NUMBER(1) DEFAULT 0,
  brand_name VARCHAR2(255),
  business_type VARCHAR2(100),
  website VARCHAR2(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
```

### 2. Posts/Vibes Table
```sql
CREATE TABLE posts (
  post_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id NUMBER NOT NULL,
  content CLOB NOT NULL,
  media_urls CLOB, -- JSON array stored as CLOB
  audio_url VARCHAR2(500),
  tags CLOB, -- JSON array stored as CLOB
  likes_count NUMBER DEFAULT 0,
  comments_count NUMBER DEFAULT 0,
  shares_count NUMBER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_posts_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_posts_user ON posts(user_id);
CREATE INDEX idx_posts_created ON posts(created_at DESC);
```

### 3. Post Likes Table
```sql
CREATE TABLE post_likes (
  like_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  post_id NUMBER NOT NULL,
  user_id NUMBER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_likes_post FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE,
  CONSTRAINT fk_likes_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT uk_post_user_like UNIQUE (post_id, user_id)
);

CREATE INDEX idx_likes_post ON post_likes(post_id);
CREATE INDEX idx_likes_user ON post_likes(user_id);
```

### 4. Comments Table
```sql
CREATE TABLE comments (
  comment_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  post_id NUMBER NOT NULL,
  user_id NUMBER NOT NULL,
  comment_text VARCHAR2(1000) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_comments_post FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_comments_post ON comments(post_id);
CREATE INDEX idx_comments_user ON comments(user_id);
```

### 5. Events Table
```sql
CREATE TABLE events (
  event_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  organizer_id NUMBER NOT NULL,
  title VARCHAR2(255) NOT NULL,
  description CLOB NOT NULL,
  start_date TIMESTAMP NOT NULL,
  end_date TIMESTAMP NOT NULL,
  location VARCHAR2(500) NOT NULL,
  category VARCHAR2(100) NOT NULL,
  price NUMBER(10,2) NOT NULL,
  currency VARCHAR2(10) DEFAULT 'USD',
  capacity NUMBER NOT NULL,
  attendees_count NUMBER DEFAULT 0,
  image_url VARCHAR2(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_events_organizer FOREIGN KEY (organizer_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_events_organizer ON events(organizer_id);
CREATE INDEX idx_events_category ON events(category);
CREATE INDEX idx_events_dates ON events(start_date, end_date);
```

### 6. Event Bookings Table
```sql
CREATE TABLE event_bookings (
  booking_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  event_id NUMBER NOT NULL,
  user_id NUMBER NOT NULL,
  quantity NUMBER NOT NULL,
  total_amount NUMBER(10,2) NOT NULL,
  booking_status VARCHAR2(50) DEFAULT 'pending',
  payment_status VARCHAR2(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bookings_event FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE,
  CONSTRAINT fk_bookings_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_bookings_event ON event_bookings(event_id);
CREATE INDEX idx_bookings_user ON event_bookings(user_id);
CREATE INDEX idx_bookings_status ON event_bookings(booking_status);
```

### 7. Conversations Table
```sql
CREATE TABLE conversations (
  conversation_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  conversation_type VARCHAR2(50) DEFAULT 'direct', -- direct, group, community
  title VARCHAR2(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 8. Conversation Participants Table
```sql
CREATE TABLE conversation_participants (
  participant_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  conversation_id NUMBER NOT NULL,
  user_id NUMBER NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_participants_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE,
  CONSTRAINT fk_participants_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT uk_conversation_user UNIQUE (conversation_id, user_id)
);

CREATE INDEX idx_participants_conversation ON conversation_participants(conversation_id);
CREATE INDEX idx_participants_user ON conversation_participants(user_id);
```

### 9. Messages Table
```sql
CREATE TABLE messages (
  message_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  conversation_id NUMBER NOT NULL,
  sender_id NUMBER NOT NULL,
  message_text CLOB NOT NULL,
  media_url VARCHAR2(500),
  is_read NUMBER(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_messages_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE,
  CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_created ON messages(created_at DESC);
```

### 10. Payments Table
```sql
CREATE TABLE payments (
  payment_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  booking_id NUMBER NOT NULL,
  user_id NUMBER NOT NULL,
  amount NUMBER(10,2) NOT NULL,
  currency VARCHAR2(10) DEFAULT 'USD',
  payment_method VARCHAR2(100) NOT NULL,
  payment_status VARCHAR2(50) DEFAULT 'pending',
  transaction_id VARCHAR2(255),
  payment_details CLOB, -- JSON stored as CLOB
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) REFERENCES event_bookings(booking_id) ON DELETE CASCADE,
  CONSTRAINT fk_payments_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
```

### 11. Travel Bookings Table (Flights/Accommodations)
```sql
CREATE TABLE travel_bookings (
  travel_booking_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id NUMBER NOT NULL,
  booking_type VARCHAR2(50) NOT NULL, -- flight, accommodation, transport
  booking_details CLOB NOT NULL, -- JSON stored as CLOB
  total_amount NUMBER(10,2) NOT NULL,
  currency VARCHAR2(10) DEFAULT 'USD',
  booking_status VARCHAR2(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_travel_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_travel_user ON travel_bookings(user_id);
CREATE INDEX idx_travel_type ON travel_bookings(booking_type);
```

## API Endpoints Specification

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/setup-organizer` - Complete organizer profile
- `POST /api/auth/logout` - User logout

### Posts/Vibes Endpoints
- `GET /api/posts?page={page}&limit={limit}` - Fetch posts feed
- `POST /api/posts` - Create new post
- `POST /api/posts/{postId}/like` - Like post
- `DELETE /api/posts/{postId}/like` - Unlike post
- `POST /api/posts/{postId}/comments` - Add comment

### Events Endpoints
- `GET /api/events?category={cat}&location={loc}&start_date={date}&end_date={date}&page={page}&limit={limit}` - Fetch events
- `POST /api/events` - Create event
- `POST /api/events/{eventId}/book` - Book event ticket

### Messaging Endpoints
- `GET /api/messages/conversations` - Fetch conversations
- `GET /api/messages/conversations/{conversationId}?page={page}&limit={limit}` - Fetch messages
- `POST /api/messages/conversations/{conversationId}` - Send message

### Travel Endpoints
- `GET /api/travel/flights?origin={origin}&destination={dest}&depart_date={date}&return_date={date}` - Search flights
- `GET /api/travel/accommodations?location={loc}&check_in={date}&check_out={date}&guests={num}` - Search accommodations

### Payment Endpoints
- `POST /api/payments` - Process payment
- `GET /api/payments/history` - Get payment history

### User Profile Endpoints
- `GET /api/users/{userId}` - Get user profile
- `PUT /api/users/profile` - Update profile
- `GET /api/users/search?q={query}` - Search users

### WebSocket Events
- `chat_message` - Real-time chat message
- `typing` - Typing indicator
- `join_conversation` - Join conversation room
- `leave_conversation` - Leave conversation room

## Backend Implementation Notes

### Technology Stack Recommendations
- **Backend Framework**: Node.js with Express, Python with FastAPI, or Java with Spring Boot
- **Database**: Oracle Autonomous Database or Oracle MySQL
- **WebSocket**: Socket.io (Node.js) or native WebSocket implementation
- **Authentication**: JWT tokens with SHA-256 password hashing
- **File Storage**: Oracle Object Storage for media files

### Security Requirements
- All API endpoints require authentication via Bearer token (except login/register)
- API key validation for all requests
- HTTPS/WSS encryption for all communications
- SQL injection prevention using parameterized queries
- Rate limiting on API endpoints

### Deployment Checklist
1. Set up Oracle VPS instance
2. Install Oracle Database (Autonomous DB or MySQL)
3. Execute all table creation scripts
4. Deploy backend application
5. Configure environment variables:
   - Database connection strings
   - JWT secret key
   - API keys
   - WebSocket server port
6. Set up SSL certificates for HTTPS/WSS
7. Configure firewall rules
8. Update Flutter app environment variables with production URLs

## Environment Variables Required

### Flutter App (env.json)
```json
{
  "ORACLE_API_BASE_URL": "https://your-oracle-vps.com/api",
  "ORACLE_API_KEY": "your-api-key-here",
  "ORACLE_WS_URL": "wss://your-oracle-vps.com/ws"
}
```

### Backend Server
```
DATABASE_HOST=your-oracle-db-host
DATABASE_PORT=1521
DATABASE_NAME=vibelink
DATABASE_USER=admin
DATABASE_PASSWORD=your-password
JWT_SECRET=your-jwt-secret
API_KEY=your-api-key
WS_PORT=8080
```
