import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_image_widget.dart';
import './custom_rating_bar.dart';

class ReviewCardWidget extends StatelessWidget {
  final Map<String, dynamic> review;

  const ReviewCardWidget({super.key, required this.review});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final userName = review['user_name'] as String? ?? 'Anonymous';
    final userAvatar = review['user_avatar'] as String?;
    final rating = (review['rating'] as num?)?.toDouble() ?? 0.0;
    final reviewText = review['review_text'] as String? ?? '';
    final createdAt = review['created_at'] as String? ?? '';
    final photos = review['photo_urls'] as List<dynamic>? ?? [];

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: theme.colorScheme.secondary.withValues(
                  alpha: 0.2,
                ),
                child: userAvatar != null
                    ? ClipOval(
                        child: CustomImageWidget(
                          imageUrl: userAvatar,
                          width: 40,
                          height: 40,
                          fit: BoxFit.cover,
                          semanticLabel: 'Profile picture of $userName',
                        ),
                      )
                    : Text(
                        userName[0].toUpperCase(),
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.secondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      userName,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      _formatDate(createdAt),
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              CustomRatingBar(
                rating: rating,
                itemSize: 16,
                color: theme.colorScheme.secondary,
                isIndicator: true,
              ),
            ],
          ),
          if (reviewText.isNotEmpty) ...[
            SizedBox(height: 2.h),
            Text(
              reviewText,
              style: theme.textTheme.bodyMedium,
              maxLines: 5,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          if (photos.isNotEmpty) ...[
            SizedBox(height: 2.h),
            SizedBox(
              height: 80,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: photos.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: EdgeInsets.only(right: 2.w),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CustomImageWidget(
                        imageUrl: photos[index] as String,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                        semanticLabel: 'Review photo ${index + 1}',
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inDays == 0) {
        if (difference.inHours == 0) {
          return '${difference.inMinutes}m ago';
        }
        return '${difference.inHours}h ago';
      } else if (difference.inDays < 7) {
        return '${difference.inDays}d ago';
      } else if (difference.inDays < 30) {
        return '${(difference.inDays / 7).floor()}w ago';
      } else {
        return '${date.day}/${date.month}/${date.year}';
      }
    } catch (e) {
      return dateStr;
    }
  }
}
