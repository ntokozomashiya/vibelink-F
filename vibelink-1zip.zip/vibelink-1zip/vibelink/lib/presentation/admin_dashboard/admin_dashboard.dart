import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:sizer/sizer.dart';

import '../../services/oracle_api_service.dart';
import '../../widgets/custom_app_bar.dart';

/// Admin Dashboard Screen - Platform management and analytics
class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoadingAnalytics = false;
  bool _isLoadingVerifications = false;
  bool _isLoadingFraud = false;
  Map<String, dynamic>? _platformAnalytics;
  List<Map<String, dynamic>> _pendingVerifications = [];
  List<Map<String, dynamic>> _fraudAlerts = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    _loadPlatformAnalytics();
    _loadPendingVerifications();
    _loadFraudAlerts();
  }

  Future<void> _loadPlatformAnalytics() async {
    setState(() => _isLoadingAnalytics = true);

    try {
      final analytics = await OracleApiService.getPlatformAnalytics();
      setState(() {
        _platformAnalytics = analytics;
        _isLoadingAnalytics = false;
      });
    } catch (e) {
      setState(() => _isLoadingAnalytics = false);
    }
  }

  Future<void> _loadPendingVerifications() async {
    setState(() => _isLoadingVerifications = true);

    try {
      final verifications = await OracleApiService.getPendingVerifications();
      setState(() {
        _pendingVerifications = verifications;
        _isLoadingVerifications = false;
      });
    } catch (e) {
      setState(() => _isLoadingVerifications = false);
    }
  }

  Future<void> _loadFraudAlerts() async {
    setState(() => _isLoadingFraud = true);

    try {
      final alerts = await OracleApiService.getFraudAlerts();
      setState(() {
        _fraudAlerts = alerts;
        _isLoadingFraud = false;
      });
    } catch (e) {
      setState(() => _isLoadingFraud = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: CustomAppBar(
        variant: CustomAppBarVariant.detail,
        showBackButton: true,
        title: 'Admin Dashboard',
      ),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.colorScheme.outline),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: theme.colorScheme.secondary,
                borderRadius: BorderRadius.circular(10),
              ),
              labelColor: theme.colorScheme.onSecondary,
              unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
              tabs: const [
                Tab(text: 'Analytics'),
                Tab(text: 'Verifications'),
                Tab(text: 'Fraud Alerts'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildAnalyticsTab(theme),
                _buildVerificationsTab(theme),
                _buildFraudAlertsTab(theme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalyticsTab(ThemeData theme) {
    if (_isLoadingAnalytics) {
      return Center(
        child: CircularProgressIndicator(color: theme.colorScheme.secondary),
      );
    }

    final analytics =
        _platformAnalytics ??
        {
          'total_users': 45678,
          'total_events': 1234,
          'total_revenue': 'R 8,945,670',
          'platform_fees': 'R 894,567',
          'active_boosts': 89,
          'revenue_by_month': [
            {'month': 'Jan', 'revenue': 650000},
            {'month': 'Feb', 'revenue': 720000},
            {'month': 'Mar', 'revenue': 890000},
            {'month': 'Apr', 'revenue': 1050000},
            {'month': 'May', 'revenue': 1200000},
            {'month': 'Jun', 'revenue': 1450000},
          ],
        };

    return ListView(
      padding: EdgeInsets.all(4.w),
      children: [
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                'Total Users',
                analytics['total_users'].toString(),
                Icons.people,
                theme.colorScheme.secondary,
                theme,
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: _buildStatCard(
                'Total Events',
                analytics['total_events'].toString(),
                Icons.event,
                theme.colorScheme.tertiary,
                theme,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                'Total Revenue',
                analytics['total_revenue'],
                Icons.attach_money,
                Colors.green,
                theme,
              ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: _buildStatCard(
                'Platform Fees',
                analytics['platform_fees'],
                Icons.account_balance,
                Colors.blue,
                theme,
              ),
            ),
          ],
        ),
        SizedBox(height: 3.h),
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: theme.colorScheme.outline.withValues(alpha: 0.2),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Platform Revenue Trend',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 2.h),
              SizedBox(
                height: 25.h,
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: true, drawVerticalLine: false),
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 50,
                          getTitlesWidget: (value, meta) {
                            return Text(
                              'R${(value / 1000).toInt()}k',
                              style: theme.textTheme.labelSmall,
                            );
                          },
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: (value, meta) {
                            final months = analytics['revenue_by_month'];
                            if (value.toInt() >= 0 &&
                                value.toInt() < months.length) {
                              return Text(
                                months[value.toInt()]['month'],
                                style: theme.textTheme.labelSmall,
                              );
                            }
                            return const Text('');
                          },
                        ),
                      ),
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                    ),
                    borderData: FlBorderData(show: false),
                    lineBarsData: [
                      LineChartBarData(
                        spots: List.generate(
                          analytics['revenue_by_month'].length,
                          (index) => FlSpot(
                            index.toDouble(),
                            analytics['revenue_by_month'][index]['revenue']
                                .toDouble(),
                          ),
                        ),
                        isCurved: true,
                        color: theme.colorScheme.secondary,
                        barWidth: 3,
                        dotData: const FlDotData(show: true),
                        belowBarData: BarAreaData(
                          show: true,
                          color: theme.colorScheme.secondary.withValues(
                            alpha: 0.1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildVerificationsTab(ThemeData theme) {
    if (_isLoadingVerifications) {
      return Center(
        child: CircularProgressIndicator(color: theme.colorScheme.secondary),
      );
    }

    if (_pendingVerifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.verified_user_outlined,
              size: 20.w,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            SizedBox(height: 2.h),
            Text(
              'No pending verifications',
              style: theme.textTheme.titleMedium,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(4.w),
      itemCount: _pendingVerifications.length,
      itemBuilder: (context, index) {
        final verification = _pendingVerifications[index];
        return _buildVerificationCard(verification, theme);
      },
    );
  }

  Widget _buildVerificationCard(
    Map<String, dynamic> verification,
    ThemeData theme,
  ) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage(
                  verification['user_avatar'] ??
                      'https://images.unsplash.com/photo-1730222168387-051038de25be',
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      verification['user_name'] ?? 'User',
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      verification['verification_type'] ?? 'Host Verification',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'PENDING',
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: Colors.orange,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () =>
                      _rejectVerification(verification['verification_id']),
                  icon: const Icon(Icons.close),
                  label: const Text('Reject'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () =>
                      _approveVerification(verification['verification_id']),
                  icon: const Icon(Icons.check),
                  label: const Text('Approve'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFraudAlertsTab(ThemeData theme) {
    if (_isLoadingFraud) {
      return Center(
        child: CircularProgressIndicator(color: theme.colorScheme.secondary),
      );
    }

    if (_fraudAlerts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shield_outlined,
              size: 20.w,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            SizedBox(height: 2.h),
            Text('No fraud alerts', style: theme.textTheme.titleMedium),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: EdgeInsets.all(4.w),
      itemCount: _fraudAlerts.length,
      itemBuilder: (context, index) {
        final alert = _fraudAlerts[index];
        return _buildFraudAlertCard(alert, theme);
      },
    );
  }

  Widget _buildFraudAlertCard(Map<String, dynamic> alert, ThemeData theme) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withValues(alpha: 0.3), width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 6.w),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  alert['alert_type'] ?? 'Fraud Alert',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: Colors.red,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            alert['description'] ?? 'No description',
            style: theme.textTheme.bodyMedium,
          ),
          SizedBox(height: 1.h),
          Text(
            'Reported: ${alert['created_at'] ?? 'Unknown'}',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 2.h),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              child: const Text('Investigate'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    String label,
    String value,
    IconData icon,
    Color color,
    ThemeData theme,
  ) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 8.w),
          SizedBox(height: 1.h),
          Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _approveVerification(int verificationId) async {
    try {
      await OracleApiService.approveVerification(verificationId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Verification approved!'),
            backgroundColor: Colors.green,
          ),
        );
        _loadPendingVerifications();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to approve: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _rejectVerification(int verificationId) async {
    final reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reject Verification'),
        content: TextField(
          controller: reasonController,
          decoration: const InputDecoration(
            labelText: 'Reason for rejection',
            hintText: 'Enter reason...',
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (reasonController.text.isNotEmpty) {
                Navigator.pop(context);
                try {
                  await OracleApiService.rejectVerification(
                    verificationId,
                    reasonController.text,
                  );
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Verification rejected'),
                        backgroundColor: Colors.orange,
                      ),
                    );
                    _loadPendingVerifications();
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Failed to reject: ${e.toString()}'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Reject'),
          ),
        ],
      ),
    );
  }
}
