import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_image_widget.dart';
import './widgets/login_tab_widget.dart';
import './widgets/profile_setup_modal_widget.dart';
import './widgets/register_tab_widget.dart';

/// Authentication & Onboarding screen with tabbed login/register interface
class AuthenticationOnboarding extends StatefulWidget {
  const AuthenticationOnboarding({super.key});

  @override
  State<AuthenticationOnboarding> createState() =>
      _AuthenticationOnboardingState();
}

class _AuthenticationOnboardingState extends State<AuthenticationOnboarding>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Map<String, dynamic>? _registeredUserData;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _handleLoginSuccess() {
    HapticFeedback.mediumImpact();
    Navigator.pushReplacementNamed(context, '/home-feed');
  }

  void _handleRegisterSuccess(Map<String, dynamic> userData) {
    setState(() => _registeredUserData = userData);
    _showProfileSetupModal();
  }

  void _showProfileSetupModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (context) => ProfileSetupModalWidget(
        userData: _registeredUserData!,
        onComplete: () {
          Navigator.pop(context);
          _handleLoginSuccess();
        },
      ),
    );
  }

  void _switchToRegister() {
    HapticFeedback.selectionClick();
    _tabController.animateTo(1);
  }

  void _switchToLogin() {
    HapticFeedback.selectionClick();
    _tabController.animateTo(0);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Logo and branding
            Padding(
              padding: EdgeInsets.symmetric(vertical: 4.h),
              child: Column(
                children: [
                  // Logo
                  Container(
                    width: 20.w,
                    height: 20.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: CustomImageWidget(
                        imageUrl: 'assets/images/1000238035-1767648250313.jpg',
                        width: 20.w,
                        height: 20.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'VibeLink',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  // Tagline
                  Text(
                    'Connect. Discover. Experience.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),

            // Tab bar
            Container(
              margin: EdgeInsets.symmetric(horizontal: 6.w),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: theme.colorScheme.secondary,
                  borderRadius: BorderRadius.circular(12),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: theme.colorScheme.onSecondary,
                unselectedLabelColor: theme.colorScheme.onSurfaceVariant,
                labelStyle: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                unselectedLabelStyle: theme.textTheme.titleMedium,
                tabs: const [
                  Tab(text: 'Login'),
                  Tab(text: 'Register'),
                ],
              ),
            ),

            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  LoginTabWidget(
                    onLoginSuccess: _handleLoginSuccess,
                    onSwitchToRegister: _switchToRegister,
                  ),
                  RegisterTabWidget(
                    onRegisterSuccess: _handleRegisterSuccess,
                    onSwitchToLogin: _switchToLogin,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
